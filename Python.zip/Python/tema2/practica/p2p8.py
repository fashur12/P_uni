def leer_archivo():
    ruta = r"C:/Users/estudiante/Desktop/Python/tema2/practica/p2p8.txt"
    stock = []
    with open(ruta, "r") as archivo:
        for linea in archivo:
            codigo, nombre, precio = linea.strip().split(';')
            stock.append((codigo, nombre.lower(), float(precio)))
    return stock

def escribir(stock):
    
    ruta = r"C:/Users/estudiante/Desktop/Python/tema2/practica/compras.txt"
    with open(ruta, 'w') as archivo:
        for codigo, nombre, precio in stock:
            archivo.write(f"{codigo} {nombre} {precio}\n")


productos = leer_archivo()
escribir(productos)==input("ingrese el producto que desea escribir")
print(f"llo escrito fue {productos}")