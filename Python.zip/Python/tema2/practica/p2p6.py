def leer_archivo():
    ruta = r"C:/Users/estudiante/Desktop/Python/tema2/practica/p2p6.txt"
    with open(ruta, "r") as archivo:
        lista_lineas = [float(linea.strip()) for linea in archivo]
    print("Líneas:", len(lista_lineas))
    return lista_lineas

def promedio(recorrido):
    distancia_total = 0
    cont = 0
    for distancia in recorrido:  # Usar la lista `recorrido` en lugar de `distancia`
        distancia_total += distancia
        cont += 1
    promedio = distancia_total / cont if cont > 0 else 0
    return promedio

def mayor(distancia, promedio):
    mayores = []
    for valor in distancia:  
        if valor > promedio:
            mayores.append(valor)
    return mayores  

def mostrar(promedio, mayores):
    print(f"La distancia de los viajes en promedio es: {promedio:.2f}")
    print(f"Las distancias mayores al promedio son: { mayores}")


distancias = leer_archivo()
promedio_distancia = promedio(distancias)
mayores_distancias = mayor(distancias, promedio_distancia)
mostrar(promedio_distancia, mayores_distancias)
