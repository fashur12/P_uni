dia = int(input("Ingrese el dia: "))
mes = int(input("Ingrese el mes: "))
año = int(input("Ingrese el año: "))

def validarFecha(dia, mes, año):
    if dia<0 or dia>32:
     return False 
    elif mes<0 or mes>12:
     return False 
    if año<0: 
      return False 
    else: 
      return True


valido = validarFecha(dia,mes,año)

def EsBisiesto(año):
    if (año % 4 == 0 and año % 100 != 0) or (año % 400 == 0):
        return True
    else:
        return False

bisiesto = EsBisiesto(año)

if valido ==False:
    print("ingrese una fecha valida")
if bisiesto:
    print(f"El año es bisiesto, {dia}/{mes}/{año}")
else:
    print(f"El año {año} no es bisiesto.")


