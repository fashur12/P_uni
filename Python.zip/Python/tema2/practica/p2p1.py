def invertido(cadena):

    cadena_invertida = ''

    for caracter in cadena:

        cadena_invertida = caracter + cadena_invertida
        
    return cadena_invertida

def es_palindromo(cadena):
    cadena = cadena.lower()
    
    cadena_invertida = invertido(cadena)
def es_palindromo(cadena):

    cadena = cadena.lower()
    cadena_invertida = invertido(cadena)

    return cadena == cadena_invertida


entrada = input("Ingrese una cadena: ")
cadena_invertida = invertido(entrada)
print(f"La cadena invertida es: {cadena_invertida}")

if es_palindromo(entrada):
    print(f'"{entrada}" es un palindromo.')
else:
    print(f'"{entrada}" no es un palidromo.')
