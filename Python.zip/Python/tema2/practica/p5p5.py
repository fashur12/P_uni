class Especies:
    def __init__(self, nombre : str):
        self.nombre = nombre
        self.machos= 0
        self.hembras = 0
        self.ritmo= 0.0

        def establecerMachos(self, cantHembras: int):
            self.hembras = cantHembras

            def estabecerMachos(self,cantMachos:int):
                self.machos = cantMachos

        def establecerRitmo(self,ritmo:float):
            self.ritmo = ritmo

        def actualizarHembras(self,cantHembras:int):
            self.hembras += cantHembras

        def actualizarMachos(self,cantMachos:int):
            self.hembras += cantMachos
            
        def actualizarRitmo(self, ritmo: float):
            self.ritmo = ritmo


        def poblacionActual(self) -> int:
            return self.machos + self.hembras
        
        def poblacionEstmimada(self, anios: int)-> int:
         return int(self.poblacionActual() * ((1 + self.ritmo) ** anios))
        
        def aniosParaPoblacion(self, poblacion: int) -> int:
         actual = self.poblacionActual() 
         anios = 0
         while actual < poblacion:
          actual += actual * self.ritmo
        anios += 1
        return anios
    
        def riesgo(self) -> str:
         if self.poblacionActual() < 50:
            return "Alto riesgo de extinción"
         elif 50 <= self.poblacionActual() < 100:
            return "Riesgo moderado"
         else:
            return "Bajo riesgo"
    
    def masHembras(self) -> bool:
        return self.hembras > self.machos
    
        def mayorRitmo(self, otraEspecie: 'Especie') -> 'Especie':
         return self if self.ritmo > otraEspecie.ritmo else otraEspecie
    
        def clonar(self) -> 'Especie':
         clon = Especie(self.nombre)
         clon.machos = self.machos
        clon.hembras = self.hembras
        clon.ritmo = self.ritmo
        return clon
    
    def __str__(self) -> str:
        return (f"Especie: {self.nombre}, Machos: {self.machos}, Hembras: {self.hembras}, "
                f"Ritmo de crecimiento: {self.ritmo}")

