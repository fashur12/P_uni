cantidad = int(input("Ingrese la cantidad de notas que desea ingresar: "))
notas = []


for i in range(cantidad):
    nota = int(input(f"Ingrese la nota del alumno numero {i + 1}: "))
    notas.append(nota)


for i in range(cantidad - 1):
    for j in range(i + 1, cantidad):
        if notas[i] < notas[j]:
            aux = notas[i]
            notas[i] = notas[j]
            notas[j] = aux


for i in range(cantidad):
    print(f"Las notas son: {notas[i]}")
