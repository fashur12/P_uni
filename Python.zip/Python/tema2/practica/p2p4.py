
solicitud = input("Ingrese un numero: ")


try:
    numero = int(solicitud)
    

    lista_digitos = [int(digito) for digito in solicitud]


    indice_mayor = lista_digitos.index(max(lista_digitos))

    print(f"El indice del digito mayor es: {indice_mayor}")

except ValueError:
    print("La entrada no es un numero valido.")
