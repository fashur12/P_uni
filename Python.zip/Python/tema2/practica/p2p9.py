def agregar_alumno():

    legajo = input("Ingrese el legajo del alumno: ")
    apellido = input("Ingrese el apellido del alumno: ")
    nombre = input("Ingrese el nombre del alumno: ")
    oral = input("Ingrese la nota del oral: ")
    escrito = input("Ingrese la nota del escrito: ")
    tp = input("Ingrese la nota del trabajo practico: ")


    promedio = (float(oral) + float(escrito) + float(tp)) / 3
    promocion = promedio > 7


    with open('C:/Users/estudiante/Desktop/Python/tema2/practica/alumnos.txt', 'a') as archivo_alumnos:
        archivo_alumnos.write(f"{legajo};{oral};{escrito};{tp}\n")


    with open('C:/Users/estudiante/Desktop/Python/tema2/practica/apellidos.txt', 'a') as archivo_apellidos:
        archivo_apellidos.write(f"{legajo};{apellido};{nombre}\n")


    if promocion:
        with open('C:/Users/estudiante/Desktop/Python/tema2/practica/promocion.txt', 'a') as archivo_promocion:
            archivo_promocion.write(f"{apellido};{nombre}\n")

    print("Datos del alumno agregados exitosamente.")


agregar_alumno()
