def pruebas (notas):
    return "aprobado" if notas>=40 else "desaprobado"

alumnos=[]
cantidad_alumnos = int(input("Ingrese la cantidad de alumnos: "))

for i in range(cantidad_alumnos):
    nombre=input("ingrese el nombre del alumno")
    nota=float(input("ingrese la nota del alumno "))
    alumnos.append((nombre,nota))

print("alumno/nota/aprobado")
for nombre, nota in alumnos:
  resultado = pruebas(nota)
  print(f"{nombre}\t{nota}\t{resultado}")
