
def leer_archivo():
    ruta = r"C:/Users/estudiante/Desktop/Python/tema2/practica/p2p7.txt"
    productos = []
    with open(ruta, "r") as archivo:
        for linea in archivo:
            codigo, nombre, precio = linea.strip().split(';')
            productos.append((codigo, nombre.lower(), float(precio)))
    return productos

def buscar_precio(productos, nombre_produc):
    for codigo, nombre, precio in productos:
        if nombre == nombre_produc.lower():
            return precio 
    return None  

def main():
    productos = leer_archivo()
    nombre_producto = input("Ingrese el nombre del producto que desea buscar: ")
    precio = buscar_precio(productos, nombre_producto)
    if precio is not None:
        print(f"El precio de {nombre_producto} es {precio}")
    else:
        print("Producto no encontrado")

if __name__ == "__main__":
    main()
