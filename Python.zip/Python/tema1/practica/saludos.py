print("hola")
edad=int(input("ingrese su edad: "))
print(f"la edad es: {edad}")
base=float(input("ingrese la base: "))
if base>0 :
print("tiene que ser mayor que 0")

if altura>0 :
    print("tiene que ser mayor que 0")
altura=float(input("ingrese la altura:"))

area = base*altura
print(f"el area es: {area}")