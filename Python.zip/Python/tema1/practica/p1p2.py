#. Implemente un programa que a partir del ancho, alto y largo de una habitación
#rectangular calcule cuántos litros de pintura se necesitan para pintarla. Suponiendo
#que 1 litro de pintura sirve para 10m cuadrados y que la habitación tiene sólo una
#puerta de 0,80 de ancho por 2 mts de alto. 
ancho=float(input("ingrese el ancho de la habitacion"))
largo=float(input("ingrese ellargo de la habitacion "))
ancho_puerta = 0.80  
alto_puerta = 2.00   
area_puerta = ancho_puerta * alto_puerta
area_paredes = 2 * (ancho * alto + largo * alto)
area_a_pintar = area_paredes - area_puerta
litros_Pintura =  area_a_pintar / 10
print(f"Se necesitan {litros_pintura:.2f} litros de pintura para pintar la habitación.")