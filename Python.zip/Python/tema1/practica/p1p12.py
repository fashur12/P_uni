primero = True
ordenado = True
booleano = True

while booleano:
    numero = int(input("Ingrese numeros y si desea terminar ingrese 0: "))

    if numero == 0:
        booleano = False
    else:
        if primero:
            anterior = numero
            primero = False
        else:
            if numero < anterior:
                ordenado = False
            anterior = numero

if ordenado:
    print("La secuencia esta ordenada de menor a mayor")
else:
    print("La secuencia no esta ordenada de menor a mayor")
