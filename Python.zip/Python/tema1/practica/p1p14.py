palabra = input("ingrese una palabra para colcular la cantidad de vocales ")
vocales="aeiou"
cant_vocales=0
for letra in palabra:
    if letra in vocales:
        cant_vocales += 1
        print(f"La cantidad total de vocales es:{cant_vocales}")
