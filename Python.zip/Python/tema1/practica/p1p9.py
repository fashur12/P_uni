print("Ingrese un valor positivo  a los siguientes numeros")
numeroX=(float(input("Ingrese el valor de numero X: ")))
numeroB=(float(input("Ingrese el valor de B:")))
numeroA=(float(input("Ingrese el valor de A"))) 
if numeroA > numeroB:
    print("Error: A debe ser menor o igual que B.")
else:
    print(f"Múltiplos de {numeroX} entre {numeroA} y {numeroB}:")
    for multiplo in range(int(numeroA), int(numeroB) + 1):
        if multiplo % numeroX == 0:
            print(multiplo)