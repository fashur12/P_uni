
cantidad = int(input("Ingrese la cantidad de valores que desea ingresar: "))


suma_total = 0.0


for i in range(cantidad):
    numero = float(input(f"Ingrese el numero {i+1}: "))
    suma_total += numero  


promedio = suma_total / cantidad


print(f"El promedio de los numeros es: {promedio}")
