caracter=input("Ingrese el caracter que desea ")
cantidad= int(input("ingrese la cantudad de veces que desea colocarlo "))
for i in range(cantidad):
    print(end =caracter)
    