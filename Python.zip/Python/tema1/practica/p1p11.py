suma = 0 
count = 0 
booleano = True 

while booleano: 
    numero = int(input("Ingrese un numero entero positivo (o un numero negativo para terminar): "))
    
    if numero < 0:
        booleano = False
    else:
        suma += numero
        count += 1

if count > 0:
    promedio = suma / count
    print(f"El promedio es {promedio} con un total de {count} ingresos.")
else:
    print("No se ingresaron numeros positivos.")


