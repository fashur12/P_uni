primer_num=(float(input("ingrese el primer numero: ")))
segun_num=(float(input("ingrese el segundo numero:")))
tercer_num=(float(input("ingrese el tercer numero:")))
if (primer_num>segun_num) and (primer_num>tercer_num):
    print(f"el numero{primer_num} es el mayor")
elif (segun_num>primer_num) and (segun_num>tercer_num):
        print(f"el numero{segun_num} es el mayor")
        if(tercer_num>primer_num) and (tercer_num>segun_num):
               print(f"el numero{tercer_num} es el mayor")