lado1=int(input("ingrese la longitud del lado 1:"))
lado2=int(input("ingrese la longitud del lado 2:"))
if lado1 > 40 or lado2 > 40:
    print("El lado más largo no puede ser mayor a 40.")
else:
    for i in range(lado2):
        print('*' * lado1)