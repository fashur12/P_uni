lado1 = float(input("Ingrese el valor del primer lado del triángulo: "))
lado2 = float(input("Ingrese el valor del segundo lado del triángulo: "))
lado3 = float(input("Ingrese el valor del tercer lado del triángulo: "))

if lado1 == lado2 == lado3:
    print("El triángulo es Equilátero")
elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3:
    print("El triángulo es Isósceles")
else:
    print("El triángulo es Escaleno")
