ancho=float(input("ingrese el ancho de la habitacion"))
largo=float(input("ingrese el largo de la habitacion "))
alto = float(input("Ingrese el alto de la habitación: "))
ancho_puerta = 0.80  
alto_puerta = 2.00   
area_puerta = ancho_puerta * alto_puerta
area_paredes = 2 * (ancho * alto + largo * alto)
area_a_pintar = area_paredes - area_puerta
litros_Pintura =  area_a_pintar / 10
manos= int(input("Ingrese cuantas manos de pinturas quieres: "))
total =litros_Pintura*manos
print(f"Se necesitan {total} litros de pintura para pintar la habitación.")