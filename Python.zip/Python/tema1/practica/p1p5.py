palabra=(input("ingrese una oracion:"))
contador_espacios = palabra.count(' ')
print(f"la cantidad de los espacion son: {contador_espacios}")