oracion=input("ingrese una oracion:")
palabra= oracion.split()
palabra_larga = ""
longitud_larga = 0
for palabra in palabra:
    if len(palabra) > longitud_larga:
        palabra_larga = palabra
        longitud_larga = len(palabra)
        print(f"La palabra mas larga es: {palabra_larga}")
print(f"Tiene {longitud_larga} letra")
