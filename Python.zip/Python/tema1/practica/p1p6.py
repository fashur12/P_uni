
numero = int(input("Ingresa un numero entero positivo: "))

if numero > 0:
    for i in range(0, numero + 1):
        print(i, end=" ")
else:
    print("El numero ingresado no es positivo.")
