class Disciplina: 
    def __init__(self, nombre : str, descripcion: str):
        self.nombre = nombre
        self.descripcion = descripcion


        def registrar (self):
            pass