from tp6p6 import Participantes
from tp6p6Disciplina import Disciplina
class torneo: 
    def __init__(self):
        self.participantes = []
        self.disciplinas = []

        
        def agregarParticipante (self, particpante):
            self.participantes.append(particpante)

        def agregarDisciplina (self, disciplina):
            self.disciplinas.append(disciplina)

        def verParticipantesPorDisciplina(self,disciplina):
         participantes_por_disciplina = [p.nobre for p in self.participantes]
         return participantes_por_disciplina
        def verDisciplinasPorParticipante(self, participante):
            disciplinas_por_participante = [d.nombre for d in self.disciplinas if participante]
            return disciplinas_por_participante
