from tp6p6 import participantes
from tp6p6Disciplina import Disciplina
from tp6p6Junto import torneo
class Tester:
    def __init__(self):
        self.torneo = torneo()

    def registrarDisciplinas(self):
        
        disciplinas = [
            Disciplina("Carreras de 100 metros", "Carrera de 100 metros"),
            Disciplina("Carreras de 400 metros", "Carrera de 400 metros"),
            # 
        ]
        for disciplina in disciplinas:
            self.torneo.agregarDisciplina(disciplina)

    def registrarParticipantes(self):
        
        participantes = [
            participante("Juan", 25, "Argentina"),
            participante("Maria", 30, "Brasil"),
            
        ]
        for participante in participantes:
            self.torneo.agregarParticipante(participante)

    def verParticipantesPorDisciplina(self):
        
        disciplina = input("Ingrese el nombre de la disciplina: ")
        participantes = self.torneo.verParticipantesPorDisciplina(disciplina)
        print(f"Participantes en {disciplina}:")
        for participante in participantes:
            print(participante)

    def verDisciplinasPorParticipante(self):
        
        participante = input("Ingrese el nombre del participante: ")
        disciplinas = self.torneo.verDisciplinasPorParticipante(participante)
        print(f"Disciplinas de {participante}:")
        for disciplina in disciplinas:
            print(disciplina)


tester = Tester()
tester.registrarDisciplinas()
tester.registrarParticipantes()
tester.verParticipantesPorDisciplina()
tester.verDisciplinasPorParticipante()