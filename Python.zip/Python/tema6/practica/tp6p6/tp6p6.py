class Participante: 
 def __init__(self, nombre: str, edad: int, nacionalidad: str):
    self.nombre = nombre
    self.edad = edad
    self.nacionaliad = nacionalidad

    def registrar(self):
      pass
    

