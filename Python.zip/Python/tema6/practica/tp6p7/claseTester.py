from Mascota import Mascota
from Cuidador import Cuidador



cuidador1 = Cuidador("Juan Pérez", "Calle Falsa 123", "555-1234")
cuidador2 = Cuidador("Ana López", "Av. Siempre Viva 456", "555-5678")


mascota1 = Mascota("Bobby", "Perro", 5, "Muy juguetón")
mascota2 = Mascota("Michi", "Gato", 3, "Muy independiente")


cuidador1.asignar_mascota(mascota1)
cuidador2.asignar_mascota(mascota2)

print(mascota1.mostrar_info())
print(mascota2.mostrar_info())

print(cuidador1.mostrar_mascotas())
print(cuidador2.mostrar_mascotas())
