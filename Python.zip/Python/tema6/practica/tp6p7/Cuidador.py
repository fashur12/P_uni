class Cuidador:
    def __init__(self, nombre:str, direccion:str, telefono:str):
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono
        self.mascotas = []

    def asignar_mascota(self, mascota):
        self.mascotas.append(mascota)
        mascota.asignar_cuidador(self)

    def mostrar_mascotas(self):
        if self.mascotas:
         return f"Mascotas a cargo de {self.nombre}: " + ", ".join([m.nombre for m in self.mascotas])
        return f"{self.nombre} no tiene mascotas asignadas."