class Mascota:
    def __init__(self, nombre, especie, edad, descripcion):
        self.nombre = nombre
        self.especie = especie
        self.edad = edad
        self.descripcion = descripcion

    def mostrar_info(self):
        return f"Nombre: {self.nombre}, Especie: {self.especie}, Edad: {self.edad}, Descripción: {self.descripcion}"

    def asignar_cuidador(self,cuidador):
         self.cuidador = cuidador

