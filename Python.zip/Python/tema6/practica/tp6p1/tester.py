from Fecha import Fecha
from socio import Socio
from libro import Libro
from prestamo import Prestamo

class Usuario:
    def __init__(self):
        self.socios = []
        self.libros = []
        self.prestamos = []

    def agregar_socio(self, nombre, fecha_nacimiento):
        socio = Socio(nombre, fecha_nacimiento)
        self.socios.append(socio)
        print(f"Socio agregado: {socio}")

    def agregar_libro(self, titulo, autor, codigo):
        libro = Libro(titulo, autor, codigo)
        self.libros.append(libro)
        print(f"Libro agregado: {libro}")

    def realizar_prestamo(self, codigo_libro, nombre_socio, dias):
        libro = next((l for l in self.libros if l.codigo == codigo_libro), None)
        socio = next((s for s in self.socios if s.nombre == nombre_socio), None)

        if libro is None:
            print(f"Error: No se encontro el libro con codigo {codigo_libro}.")
            return

        if socio is None:
            print(f"Error: No se encontro el socio con nombre {nombre_socio}.")
            return

        if not socio.estaHabilitado(Fecha.now()):
            print(f"Error: El socio {nombre_socio} esta penalizado y no puede realizar prestamos.")
            return

        fecha_prestamo = Fecha.now()
        prestamo = Prestamo(libro, fecha_prestamo, dias, socio)
        self.prestamos.append(prestamo)
        print(f"Prestamo realizado: {prestamo}")

    def devolver_libro(self, codigo_libro, nombre_socio, fecha_devolucion):
        prestamo = next((p for p in self.prestamos if p.libro.codigo == codigo_libro and p.socio.nombre == nombre_socio), None)

        if prestamo is None:
            print(f"Error: No se encontro un prestamo para el libro {codigo_libro} por el socio {nombre_socio}.")
            return

        prestamo.establecerFechaDevolucion(fecha_devolucion)
        print(f"Libro devuelto: {prestamo}")

    def mostrar_socios(self):
        print("Lista de socios:")
        for socio in self.socios:
            print(socio)

    def mostrar_libros(self):
        print("Lista de libros:")
        for libro in self.libros:
            print(libro)

    def mostrar_prestamos(self):
        print("Lista de préstamos:")
        for prestamo in self.prestamos:
            print(prestamo)


import datetime

class Fecha:
    def __init__(self, dia, mes, anio):
        self.fecha = datetime.datetime(anio, mes, dia)

    @classmethod
    def now(cls):
        hoy = datetime.datetime.now()
        return cls(hoy.day, hoy.month, hoy.year)

    def __str__(self):
        return self.fecha.strftime("%d/%m/%Y")

# Ejemplo de uso
if __name__ == "__main__":
    usuario = Usuario()
    usuario.agregar_socio("Juan Perez", Fecha(15, 5, 1990))
    usuario.agregar_libro("El Quijote", "Miguel de Cervantes", "12345")
    usuario.realizar_prestamo("12345", "Juan Perez", 10)
    usuario.mostrar_socios()
    usuario.mostrar_libros()
    usuario.mostrar_prestamos()
