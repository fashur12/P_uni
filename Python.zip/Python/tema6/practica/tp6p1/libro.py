class Libro:
    def __init__(self, titulo, autor, codigo):
        self.titulo = titulo
        self.autor = autor
        self.codigo = codigo

    def __str__(self):
        return f"Libro: {self.titulo}, Autor: {self.autor}, codigo: {self.codigo}"
