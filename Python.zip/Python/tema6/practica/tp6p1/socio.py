from Fecha import Fecha

class Socio:
    def __init__(self, nombre, nacimiento):
        self.nombre = nombre
        self.fechaNacimiento = nacimiento
        self.fechaPenalizacion = None

    def establecerPenalizacion(self, fechaHasta):
        self.fechaPenalizacion = fechaHasta

    def estaHabilitado(self, fechaActual):
        return not self.fechaPenalizacion or self.fechaPenalizacion.es_anterior(fechaActual)

    def __str__(self):
        penalizacion = f"Penalización hasta: {self.fechaPenalizacion}" if self.fechaPenalizacion else "Sin penalización"
        return f"Socio: {self.nombre}, Nacimiento: {self.fechaNacimiento}, {penalizacion}"
