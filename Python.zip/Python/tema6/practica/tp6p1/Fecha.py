from datetime import datetime, timedelta

class Fecha:
    def __init__(self, dia, mes, anio):
        self.fecha = datetime(anio, mes, dia)
    
    def __str__(self):
        return self.fecha.strftime("%d/%m/%Y")
    
    def __lt__(self, otra_fecha):
        return self.fecha < otra_fecha.fecha
    
    def __eq__(self, otra_fecha):
        return self.fecha == otra_fecha.fecha
    
    def agregar_dias(self, dias):
        self.fecha += timedelta(days=dias)
        
    def diferencia_dias(self, otra_fecha):
        return (self.fecha - otra_fecha.fecha).days
    
    def es_anterior_a(self, otra_fecha):
        return self.fecha < otra_fecha.fecha
