
class Prestamo:
    def __init__(self, libro, fechaPrestamo, cantDias, socio):
        self.libro = libro
        self.fechaPrestamo = fechaPrestamo
        self.cantDias = cantDias
        self.socio = socio
        self.fechaDevolucion = None

    def establecerFechaDevolucion(self, fechaDev):
        self.fechaDevolucion = fechaDev
        if self.devueltoATiempo():
            print("El libro fue devuelto a tiempo.")
            return
        diasPenalizados = self.calculoDePenalizacion()
        nueva_fecha_penalizacion = self.fechaDevolucion.agregar_dias(diasPenalizados)
        self.socio.establecerPenalizacion(nueva_fecha_penalizacion)
        print(f"El libro se devolvió tarde. Penalización hasta: {nueva_fecha_penalizacion}")

    def devueltoATiempo(self):
        fecha_limite = self.fechaPrestamo.agregar_dias(self.cantDias)
        return self.fechaDevolucion.es_anterior_a(fecha_limite) or self.fechaDevolucion == fecha_limite

    def calculoDePenalizacion(self):
        fecha_limite = self.fechaPrestamo.agregar_dias(self.cantDias)
        if self.fechaDevolucion.es_anterior_a(fecha_limite):
            return 0
        else:
            dias_de_retraso = (self.fechaDevolucion.dia + (self.fechaDevolucion.mes - fecha_limite.mes) * 30 +
                               (self.fechaDevolucion.anio - fecha_limite.anio) * 365) - fecha_limite.dia
            return dias_de_retraso

    def __str__(self):
        estado_devolucion = (f"Devuelto el: {self.fechaDevolucion}" if self.fechaDevolucion else "No devuelto")
        return (f"Préstamo de '{self.libro}' a {self.socio} "
                f"desde {self.fechaPrestamo} por {self.cantDias} días. {estado_devolucion}")
