from Evento import Evento
from Participante import Participante
from Organizador import Organizador


organizador1 = Organizador("Carlos Pérez", "carlos@eventos.com", "Planificación de eventos")


participante1 = Participante("Ana López", "ana@mail.com", "555-1234")
participante2 = Participante("Luis García", "luis@mail.com", "555-5678")


evento1 = Evento("Concierto de Rock", "2024-12-01", "Un concierto increíble de rock al aire libre.")


organizador1.organizar_evento(evento1)
participante1.registrar_evento(evento1)
participante2.registrar_evento(evento1)


evento1.mostrar_detalles()
