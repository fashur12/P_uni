class Evento:
    def __init__(self, nombre, fecha, descripcion):
        self.nombre = nombre
        self.fecha = fecha
        self.descripcion = descripcion
        self.organizador = None
        self.participantes = []

    def asignar_organizador(self, organizador):
        self.organizador = organizador

    def agregar_participante(self, participante):
        self.participantes.append(participante)

    def mostrar_detalles(self):
        print(f"Nombre: {self.nombre}")
        print(f"Fecha: {self.fecha}")
        print(f"Descripción: {self.descripcion}")
        if self.organizador:
            print(f"Organizador: {self.organizador.nombre}")
        if self.participantes:
            print("Participantes:")
            for participante in self.participantes:
                print(f"- {participante.nombre}")


class Participante:
    def __init__(self, nombre, email, telefono):
        self.nombre = nombre
        self.email = email
        self.telefono = telefono
        self.eventos = []

    def registrar_evento(self, evento):
        self.eventos.append(evento)

    def mostrar_eventos(self):
        if self.eventos:
            print(f"Eventos registrados por {self.nombre}:")
            for evento in self.eventos:
                print(f"- {evento.nombre}")
        else:
            print(f"{self.nombre} no tiene eventos registrados.")