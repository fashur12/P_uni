class Organizador:
    def __init__(self, nombre:str, email:str, especialidad:str):
        self.nombre = nombre
        self.email = email
        self.especialidad = especialidad
        self.eventos = []

    def organizar_evento(self, evento):
        evento.asignar_organizador(self)
        self.eventos.append(evento)
