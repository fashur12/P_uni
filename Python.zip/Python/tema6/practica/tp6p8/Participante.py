class Participante:
    def __init__(self, nombre, email, telefono):
        self.nombre = nombre
        self.email = email
        self.telefono = telefono
        self.eventos = []

    def registrar_evento(self, evento):
        self.eventos.append(evento)

    def mostrar_eventos(self):
        if self.eventos:
            print(f"Eventos registrados por {self.nombre}:")
            for evento in self.eventos:
                print(f"- {evento.nombre}")
        else:
            print(f"{self.nombre} no tiene eventos registrados.")