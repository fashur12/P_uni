# Visitante.py

class Visitante:
    def __init__(self, nombre, edad, estatura, correo_electronico):
        self.nombre = nombre
        self.edad = edad
        self.estatura = estatura
        self.correo_electronico = correo_electronico
        self.entradas = []  # Lista de entradas compradas por el visitante
        self.atracciones_visitadas = []  # Lista de atracciones visitadas

    def comprar_entrada(self, entrada):
        self.entradas.append(entrada)
        print(f"{self.nombre} ha comprado la entrada número {entrada.numero_entrada}.")

    def disfrutar_atraccion(self, atraccion, guia, turno):
        if turno not in atraccion.turnos_funcionamiento:
            print(f"La atracción {atraccion.nombre} no funciona en el turno de {turno}.")
            return

        if self.estatura < atraccion.estatura_minima:
            print(f"{self.nombre} no cumple con la estatura mínima para {atraccion.nombre}.")
            return

        if guia.autorizar_visitante(self.estatura):
            self.atracciones_visitadas.append(atraccion)
            print(f"{self.nombre} ha disfrutado de la atracción {atraccion.nombre}.")
        else:
            print(f"{self.nombre} no fue autorizado por el guía para {atraccion.nombre}.")

    def __str__(self):
        return f"Visitante: {self.nombre}, Edad: {self.edad}, Estatura: {self.estatura}m, Email: {self.correo_electronico}"
