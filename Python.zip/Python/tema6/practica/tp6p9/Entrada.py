# entrada.py

from datetime import date

class Entrada:
    def __init__(self, numero_entrada, fecha, tipo, visitante):
        self.numero_entrada = numero_entrada
        self.fecha = fecha
        self.tipo = tipo
        self.visitante = visitante

    def __str__(self):
        return f"Entrada #{self.numero_entrada} - Fecha: {self.fecha} - Tipo: {self.tipo} - Visitante: {self.visitante.nombre}"
