# Guia_aventura.py

class GuiaDeAventura:
    def __init__(self, nombre, turno_trabajo):
        """
        Inicializa un nuevo guía de aventura.

        :param nombre: Nombre del guía.
        :param turno_trabajo: Turno de trabajo del guía (mañana, tarde, noche).
        """
        self.nombre = nombre
        self.turno_trabajo = turno_trabajo

    def autorizar_visitante(self, estatura_visitante):
        """
        Autoriza al visitante para usar una atracción basada en su estatura.

        :param estatura_visitante: Estatura del visitante en metros.
        :return: True si está autorizado, False de lo contrario.
        """
        # Aquí se puede implementar lógica adicional si es necesario
        return True  # Asumiendo que la autorización depende solo de la estatura ya verificada

    def __str__(self):
        return f"Guía: {self.nombre}, Turno: {self.turno_trabajo}"
