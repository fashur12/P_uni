class Atraccion:
    def __init__(self, nombre, duracion, edad_minima, nivel_emocion):
        self.nombre = nombre
        self.duracion = duracion
        self.edad_minima = edad_minima
        self.nivel_emocion = nivel_emocion


    def __str__(self):
              return f"Nombre: {self.nombre}, Tipo: {self.tipo}, Nivel de emocional: {self.nivel_emocional}, " \
                     f"Estarura mínima: {self.estarura_minima}, Tiempo de funcionamiento: {self.turnos_funcionamiento}"