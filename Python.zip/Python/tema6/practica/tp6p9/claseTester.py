# claseTester.py

from datetime import date
from Atraccion import Atraccion
from Visitante import Visitante
from Entrada import Entrada
from Guia_aventura import GuiaDeAventura
class tester: 
    @staticmethod

    def main():

    # Crear atracciones
        montana_rusa = Atraccion(
        nombre="Montaña Rusa Extrema",
        tipo="Montaña Rusa",
        nivel_emocion="Alto",
        estatura_minima=1.40,
        turnos_funcionamiento=["mañana", "tarde"]
    )

    casa_embrujada = Atraccion(
        nombre="Casa Embrujada",
        tipo="Casa Embrujada",
        nivel_emocion="Medio",
        estatura_minima=1.20,
        turnos_funcionamiento=["tarde", "noche"]
    )

    # Crear guía
    guia_miguel = GuiaDeAventura(nombre="Miguel", turno_trabajo="tarde")

    # Crear visitante
    visitante_ana = Visitante(
        nombre="Ana Pérez",
        edad=25,
        estatura=1.35,
        correo_electronico="ana.perez@example.com"
    )

    # Crear entrada y asociarla al visitante
    entrada1 = Entrada(
        numero_entrada=1001,
        fecha=date.today(),
        tipo="General",
        visitante=visitante_ana
    )

    # El visitante compra la entrada
    visitante_ana.comprar_entrada(entrada1)

    # El visitante intenta disfrutar de las atracciones
    visitante_ana.disfrutar_atraccion(montana_rusa, guia_miguel, turno="tarde")
    visitante_ana.disfrutar_atraccion(casa_embrujada, guia_miguel, turno="noche")

    # Mostrar información
    print("\n--- Información ---")
    print(montana_rusa)
    print(casa_embrujada)
    print(guia_miguel)
    print(visitante_ana)
    for entrada in visitante_ana.entradas:
        print(entrada)
    print("Atracciones visitadas:")
    for atraccion in visitante_ana.atracciones_visitadas:
        print(f"- {atraccion.nombre}")

if __name__ == "__main__":
    main()
