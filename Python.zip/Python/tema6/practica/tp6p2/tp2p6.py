# Archivo: borde.py

from p5p3 import Color

class Borde:
    def __init__(self, grosor: int, color: Color):
        self.grosor = grosor
        self.color = color

    def copiarValores(self, borde: 'Borde'):
        """Copia los valores del borde recibido como parámetro."""
        self.grosor = borde.grosor
        self.color = borde.color.clonar()

    def clonar(self) -> 'Borde':
        """Retorna un clon del borde actual."""
        return Borde(self.grosor, self.color.clonar())

    def esIgualQue(self, borde: 'Borde') -> bool:
        """Verifica si el borde recibido es igual a la instancia actual."""
        return self.grosor == borde.grosor and self.color.esIgualQue(borde.color)

    def obtenerGrosor(self) -> int:
        """Retorna el grosor del borde."""
        return self.grosor

    def obtenerColor(self) -> Color:
        """Retorna el color del borde."""
        return self.color


if __name__ == "__main__":
    borde1 = Borde(5, Color(255, 0, 0))
    borde2 = borde1.clonar()
    print(borde1.esIgualQue(borde2))  
