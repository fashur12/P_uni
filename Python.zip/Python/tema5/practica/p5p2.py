class Fecha:
    def __init__(self, dia, mes, anio):
        self.dia = dia
        self.mes = mes
        self.anio = anio

    def esAnterior(self, otraFecha):
        if self.anio < otraFecha.anio:
            return True
        elif self.anio == otraFecha.anio:
            if self.mes < otraFecha.mes:
                return True
            elif self.mes == otraFecha.mes:
                return self.dia < otraFecha.dia
        return False

    def sumaDias(self, dias):
        dias_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        self.dia += dias
        while self.dia > dias_mes[self.mes - 1]:
            if self.mes == 2 and self.esBisiesto():
                self.dia -= 29
            else:
                self.dia -= dias_mes[self.mes - 1]
                self.mes += 1
            if self.mes > 12:
                self.mes = 1
                self.anio += 1

    def diaSiguiente(self):
        dias_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        dia_siguiente = self.dia + 1
        if dia_siguiente > dias_mes[self.mes - 1]:
            if self.mes == 2 and self.esBisiesto():
                dia_siguiente = 29
            else:
                dia_siguiente = 1
                self.mes += 1
            if self.mes > 12:
                self.mes = 1
                self.anio += 1
        return Fecha(dia_siguiente, self.mes, self.anio)

    def esIgualQue(self, otraFecha):
        return self.dia == otraFecha.dia
    def obtenerDia(self):
        return self.dia
    def ontenerMes(self):
        return self.mes

    def obtenerAnio(self):
        return self.anio
     