class Color:
    def __init__(self, rojo: int = 255, verde: int = 255, azul: int = 255):
        self.rojo = rojo
        self.verde = verde
        self.azul = azul

    def variar(self, valor: int):
        self.rojo += valor
        if self.rojo < 0:
            self.rojo = 0
        elif self.rojo > 255:
            self.rojo = 255

        self.verde += valor
        if self.verde < 0:
            self.verde = 0
        elif self.verde > 255:
            self.verde = 255

        self.azul += valor
        if self.azul < 0:
            self.azul = 0
        elif self.azul > 255:
            self.azul = 255

    def variarRojo(self, valor: int):
        self.rojo += valor
        if self.rojo < 0:
            self.rojo = 0
        elif self.rojo > 255:
            self.rojo = 255

    def variarVerde(self, valor: int):
        self.verde += valor
        if self.verde < 0:
            self.verde = 0
        elif self.verde > 255:
            self.verde = 255

    def variarAzul(self, valor: int):
        self.azul += valor
        if self.azul < 0:
            self.azul = 0
        elif self.azul > 255:
            self.azul = 255

    def establecerRojo(self, valor: int):
        if valor < 0:
            self.rojo = 0
        elif valor > 255:
            self.rojo = 255
        else:
            self.rojo = valor

    def establecerVerde(self, valor: int):
        if valor < 0:
            self.verde = 0
        elif valor > 255:
            self.verde = 255
        else:
            self.verde = valor

    def establecerAzul(self, valor: int):
        if valor < 0:
            self.azul = 0
        elif valor > 255:
            self.azul = 255
        else:
            self.azul = valor

    def copiar(self, otro_color: 'Color'):
        self.rojo = otro_color.rojo
        self.verde = otro_color.verde
        self.azul = otro_color.azul

    def obtenerRojo(self) -> int:
        return self.rojo

    def obtenerVerde(self) -> int:
        return self.verde

    def obtenerAzul(self) -> int:
        return self.azul

    def esRojo(self) -> bool:
        return self.rojo == 255 and self.verde == 0 and self.azul == 0

    def esGris(self) -> bool:
        return self.rojo == self.verde == self.azul

    def esNegro(self) -> bool:
        return self.rojo == 0 and self.verde == 0 and self.azul == 0

    def complemento(self) -> 'Color':
        return Color(255 - self.rojo, 255 - self.verde, 255 - self.azul)

    def esIgualQue(self, otro_color: 'Color') -> bool:
        return self.rojo == otro_color.rojo and self.verde == otro_color.verde and self.azul == otro_color.azul

    def clonar(self) -> 'Color':
        return Color(self.rojo, self.verde, self.azul)
