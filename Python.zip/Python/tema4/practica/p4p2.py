class Empleado:
    def __init__(self, legajo: int, HorasTrabajadasMes: int = 0, ValorHora: float = 0.0):
        self.legajo = legajo
        self.HorasTrabajadas = HorasTrabajadasMes
        self.ValorHora = ValorHora

    def CantidadHorasTrabajadas(self, CantHoras: int):
        self.HorasTrabajadas = CantHoras

    def ValorDelasHoras(self, ValorDeHoras: float):
        self.ValorHora = ValorDeHoras

    def LegajoEmpleado(self) -> int:
        return self.legajo

    def ObtenerHorasTrabajadas(self) -> int:
        return self.HorasTrabajadas

    def ObtenerValorHora(self) -> float:
        return self.ValorHora

    def ObtenerSueldo(self) -> float:
        return self.HorasTrabajadas * self.ValorHora
