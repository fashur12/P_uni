class Vinoteca:
 def __init__(self, capacidadMaxima: int=0, cantJugos: int=0, cantBlancos: int=0, cantTintosJovenes: int=0, cantTintosAnejados: int=0):
  self.capacidadMaxima = capacidadMaxima
  self.cantJugos = cantJugos
  self.cantBlancos = cantBlancos
  self.cantTintosJovenes = cantTintosJovenes
  self.cantTintosAnejados = cantTintosAnejados

def vinoteca(self):
 pass

def reponer_jugo(self, cantidad: int):
  if self.cantJugos + cantidad >self.capacidadMaxima:
    self.cantJugos = self.capacidadMaxima
  else:
    self.cantJugos +=cantidad 

def reponer_VinoBlanco(self, cantidad: int):
 if  self.cantBlancos + cantidad > self.capacidadMaxima:
   self.cantBlancos = self.capacidaMaxima
 else:
   self.cantBlancos += cantidad

def reponer_TintosJovenes(self, cantidad: int):
 if self.cantTintosJovenes + cantidad > self.cantidadMaxima:
    self.cantTintosJovenes = self.capacidadMaxima
 else: 
   self.catTintosJovenes += cantidad
def repones_TintosAnejeados(self, cantidad: int):
  if self.cantTintosAnejados + cantidad >self.capacidadMaxima: 
   self.cantTintosAnejados = self.canpacidadMaxima
  else: 
    self.cantTintosAnejados += cantidad
def obtenerCantidadJugos(self)-> int:
  return self.cantJugos
def obtenerCantidadVinosTintosBlancos(self)-> int:
  return self.cantBlancos
def obtenerCantidadVinosJovenes(self)-> int:
  return self.cantTintosJovenes
def obtenerCantidadVinosTintosAnejados(self)->int:
  return self.cantTintosAnejados

def ventaDeproductos(self, productos: str, cantidad: int)-> int:
 if productos == "jugos":
   if self.cantJugos >= cantidad:
     self.cantJugos -= cantidad
     return cantidad
   else:
    return self.cantJugos
   
 elif productos == "vinos blancos":
   if self.cantBlancos >= cantidad:
     self.cantBlancos -= cantidad
     return cantidad
   else:
     return self.cantBlancos
 elif productos == "vinos jovenes":
   if self.cantTintosJovenes >= cantidad:
     self.cantTintosJovenes -= cantidad
     return cantidad
   else: 
     return self.cantTintosJovenes
 elif productos == "vinos anejeados":
   if self.cantTintosAnejeados >= cantidad:
     self.cantTintosAnejeados -= cantidad
     return cantidad
   