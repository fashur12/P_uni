from p4p3 import Vinoteca

class VinotecaTester:
    def __init__(self):
        self.vinoteca = None
    
    def iniciar(self, cantJugos, cantBlancos, cantTintosJovenes, cantTintosAnejados):
        print("=== Configuración de la Vinoteca ===")
        capacidadMaxima = 5000

        boolean = True
        while boolean:
            try:
                
                self.vinoteca = Vinoteca(capacidadMaxima, cantJugos, cantBlancos, cantTintosJovenes, cantTintosAnejados)
                boolean = False
            except ValueError:
                print("Por favor, ingrese un valor numérico válido.")

        self.mostrar_informacion()

    def mostrar_informacion(self):
        print("\n=== Información de la Vinoteca ===")
        print(f"Capacidad maxima: {self.vinoteca.capacidadMaxima}")
        print(f"Cantidad de Jugos: {self.vinoteca.cantJugos}")
        print(f"Cantidad de Vinos Blancos: {self.vinoteca.cantBlancos}")
        print(f"Cantidad de Vinos Tintos Jovenes: {self.vinoteca.cantTintosJovenes}")
        print(f"Cantidad de Vinos Tintos Añejados: {self.vinoteca.cantTintosAnejados}\n")

    def reponer_productos(self):
        print("\n=== Reposicion de Productos ===")
        tipo_producto = input("Ingrese el producto a reponer (jugos, vinos blancos, vinos jovenes, vinos añejados): ").lower()
        cantidad = int(input("Ingrese la cantidad a reponer: "))

        if tipo_producto == "jugos":
            self.vinoteca.reponer_jugo(cantidad)
        elif tipo_producto == "vinos blancos":
            self.vinoteca.reponer_VinoBlanco(cantidad)
        elif tipo_producto == "vinos jovenes":
            self.vinoteca.reponer_TintosJovenes(cantidad)
        elif tipo_producto == "vinos añejados":
            self.vinoteca.reponer_TintosAnejados(cantidad)
        else:
            print("Producto no valido")

        self.mostrar_informacion()

    def vender_productos(self):
        print("\n=== Venta de Productos ===")
        tipo_producto = input("Ingrese el producto a vender (jugos, vinos blancos, vinos jovenes, vinos añejados): ").lower()
        cantidad = int(input("Ingrese la cantidad a vender: "))

        if tipo_producto == "jugos":
            vendido = self.vinoteca.ventaDeproductos("jugos", cantidad)
        elif tipo_producto == "vinos blancos":
            vendido = self.vinoteca.ventaDeproductos("vinos blancos", cantidad)
        elif tipo_producto == "vinos jovenes":
            vendido = self.vinoteca.ventaDeproductos("vinos jovenes", cantidad)
        elif tipo_producto == "vinos añejados":
            vendido = self.vinoteca.ventaDeproductos("vinos añejados", cantidad)
        else:
            print("Producto no valido")
            vendido = 0

        print(f"Se han vendido {vendido} unidades de {tipo_producto}")
        self.mostrar_informacion()

    def ejecutar(self):
        self.iniciar(100, 50, 25, 25)
    boleano = True
    while boleano:
            print("=== menu ===")
            print("1. Reponer productos")
            print("2. Vender productos")
            print("3. Mostrar informacion")
            print("4. Salir")
            opcion = input("Seleccione una opcion: ")

            if opcion == "1":
                self.reponer_productos()
            elif opcion == "2":
                self.vender_productos()
            elif opcion == "3":
                self.mostrar_informacion()
            elif opcion == "4":
                print("Saliendo del programa...")
                break
            else:
                print("opcion no valida. Intente de nuevo.")

tester = VinotecaTester()
tester.ejecutar()