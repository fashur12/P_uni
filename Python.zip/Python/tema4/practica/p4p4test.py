import random 
from p4p4 import Automovil

def main():
    modelo = input("Ingrese el nombre del modelo del auto: ")
    marca = input("Ingrese la marca del auto: ")
    anio = int(input("Ingrese el año donde se estreno el auto: "))
    velocidadMaxima = float(input("Ingrese la velocidad maxima que puede alcanzar el auto: "))
    velocidadActual = float(input("Ingrese la velocidad actual del auto: "))

    auto = Automovil(marca, modelo, anio, velocidadMaxima, velocidadActual)

    for _ in range(4):
        operacion = random.randint(0, 3)
        if operacion == 0:
            auto.acelerar(20)
        elif operacion == 1:
            auto.frenar(15) 
        elif operacion == 2: 
            auto.frenarCompleto()
        elif operacion == 3: 
            minutos = auto.calcularMinutosParaLlegar(50)
            print(f"Minutos para llegar: {minutos}")

if __name__ == "__main__":
    main()
