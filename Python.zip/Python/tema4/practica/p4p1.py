1. Analice si las siguientes definiciones son correctas 
a. Desde el punto de vista del diseño de un sistema orientado a objetos, una 
clase es un “molde” que establece solamente los atributos de una entidad. 
respuesta: incorrecta
b. En la Programación Orientada a Objetos se busca tratar a toda entidad como 
si fuera un objeto en la vida real, donde cada objeto tiene algunas 
propiedades y comportamientos.  
respuesta: correcta
c. El diagrama de una clase sólo especifica los atributos del objeto. 
respuesta: incorrecta
d. Los objetos tienen atributos (características) y métodos (funciones) 
asociados. 
respuesta: correcta
e. Un constructor es un método que se invoca cuando se crea un objeto. 
respuesta: correcta
f. 
Un comando es un método que nunca modifica los valores del objeto. 
respuesta: incorrecto
g. Una consulta es un método que modifica los valores del objeto. 
respuesta: incorrecto

