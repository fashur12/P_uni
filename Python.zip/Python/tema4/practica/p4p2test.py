
from p4p2 import Empleado

def main():

    legajo = int(input("Ingrese el legajo del empleado: "))
    horas_trabajadas = int(input("Ingrese la cantidad de horas trabajadas en el mes: "))
    valor_hora = float(input("Ingrese el valor de la hora trabajada: "))


    empleado = Empleado(legajo, horas_trabajadas, valor_hora)


    print(f"Legajo del empleado: {empleado.LegajoEmpleado()}")
    print(f"Sueldo calculado: ${empleado.ObtenerSueldo():.2f}")

if __name__ == "__main__":
    main()
