class Automovil:
    def __init__(self, marca: str, modelo: str, anio: int = 0, velocidadMaxima: float = 0, velocidadActual: float = 0):
        self.marca = marca
        self.modelo = modelo
        self.anio = anio
        self.velocidadMaxima = velocidadMaxima
        self.velocidadActual = velocidadActual

    def establecerMarca(self, marca: str):
        self.marca = marca

    def establecerModelo(self, modelo: str):
        self.modelo = modelo

    def establecerAnio(self, anio: int):
        self.anio = anio

    def establecerVelocidadMaxima(self, velocidadMaxima: float):
        self.velocidadMaxima = velocidadMaxima

    def establecerVelocidadActual(self, velocidadActual: float):
        self.velocidadActual = velocidadActual

    def acelerar(self, incremento: float):
        if self.velocidadActual + incremento <= self.velocidadMaxima:
            self.velocidadActual += incremento
        else:
            self.velocidadActual = self.velocidadMaxima

    def frenar(self, decremento: float):
        if self.velocidadActual - decremento >= 0:
            self.velocidadActual -= decremento
        else:
            self.velocidadActual = 0

    def frenarCompleto(self):
        self.velocidadActual = 0

    def obtenerMarca(self) -> str:
        return self.marca

    def obtenerModelo(self) -> str:
        return self.modelo

    def obtenerAnio(self) -> int:
        return self.anio

    def obtenerVelocidadMaxima(self) -> float:
        return self.velocidadMaxima

    def obtenerVelocidadActual(self) -> float:
        return self.velocidadActual

    def calcularMinutosParaLlegar(self, distanciaKM: float) -> int:
        if self.velocidadActual > 0:
            return int((distanciaKM / self.velocidadActual) * 60)
        else:
            return float('inf')
