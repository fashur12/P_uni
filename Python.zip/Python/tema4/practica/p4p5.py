class MascotaVirtual:
    def __init__(self, nombre: str, energia: int = 100, diversion: int = 100, higiene: int = 100, dormido: bool = False, cantActividadDegastante: int = 0, MAX_VALOR: int = 100, MIN_VALOR: int = 0):
        self.MAX_VALOR = MAX_VALOR
        self.MIN_VALOR = MIN_VALOR
        self.nombre = nombre
        self.energia = energia
        self.diversion = diversion
        self.higiene = higiene
        self.dormido = dormido
        self.cantActividadDegastante = cantActividadDegastante

    def comer(self):
        if self.energia + 20 >= self.MAX_VALOR:
            self.energia = self.MAX_VALOR
        else:
            self.energia += 20
        self.cantActividadDegastante = 0 

    def beber(self):
        if self.energia + 10 >= self.MAX_VALOR:
            self.energia = self.MAX_VALOR
        else:
            self.energia += 10

    def jugar(self):
        if self.diversion + 40 >= self.MAX_VALOR:
            self.diversion = self.MAX_VALOR
        else:
            self.diversion += 40
        self.cantActividadDegastante += 1
        self.higiene -= 15
        self.energia -= 20
        if self.higiene < self.MIN_VALOR:
            self.higiene = self.MIN_VALOR
        if self.energia < self.MIN_VALOR:
            self.energia = self.MIN_VALOR

    def caminar(self): 
        if self.diversion + 20 >= self.MAX_VALOR:
            self.diversion = self.MAX_VALOR
        else:
            self.diversion += 20
        self.cantActividadDegastante += 1
        self.higiene -= 8
        self.energia -= 10
        if self.higiene < self.MIN_VALOR:
            self.higiene = self.MIN_VALOR
        if self.energia < self.MIN_VALOR:
            self.energia = self.MIN_VALOR

    def saltar(self):
        if self.diversion + 10 >= self.MAX_VALOR: 
            self.diversion = self.MAX_VALOR
        else:
            self.diversion += 10
        self.energia -= 15
        self.higiene -= 10
        self.cantActividadDegastante += 1
        if self.higiene < self.MIN_VALOR:
            self.higiene = self.MIN_VALOR
        if self.energia < self.MIN_VALOR:
            self.energia = self.MIN_VALOR

    def dormir(self):
        self.dormido = True
        if self.energia + 20 >= self.MAX_VALOR:
            self.energia = self.MAX_VALOR
        else:
            self.energia += 20
        self.diversion -= 10
        if self.diversion < self.MIN_VALOR:
            self.diversion = self.MIN_VALOR

    def bañar(self):
        if self.higiene + 40 >= self.MAX_VALOR:
            self.higiene = self.MAX_VALOR
        else:
            self.higiene += 40
        self.diversion -= 10
        if self.diversion < self.MIN_VALOR:
            self.diversion = self.MIN_VALOR

    def nivel_de_energia(self):
        if self.energia == self.MIN_VALOR:
            return "se murio :("
        elif self.energia == self.MAX_VALOR:
            return "esta a 0 kilómetros"
        else:
            return "ni al maximo ni al minimo"

    def humor(self):
        if self.energia > 70 and self.diversion > 70 and self.higiene > 70:
            return "Estoy feliz :D"
        elif (self.energia >= 50 and self.energia <= 70 and 
              self.diversion >= 50 and self.diversion <= 70 and 
              self.higiene >= 50 and self.higiene <= 70):
            return "Estoy bien :)"
        elif (self.energia >= 30 and self.energia < 50 and 
              self.diversion >= 30 and self.diversion < 50 and 
              self.higiene >= 30 and self.higiene < 50):
            return "Meh :/"
        elif (self.energia >= 10 and self.energia < 30 and 
              self.diversion >= 10 and self.diversion < 30 and 
              self.higiene >= 10 and self.higiene < 30):
            return "Estoy triste :("
        else:
            return "Cai en la depresion :("

    def mostrar_estado(self):
        return (f"Nombre: {self.nombre}\n"
                f"Energia: {self.energia}\n"
                f"Divertido: {self.diversion}\n"
                f"Higiene: {self.higiene}\n"
                f"Dormido: {'Sí' if self.dormido else 'No'}\n"
                f"Actividades desgastantes: {self.cantActividadDegastante}")
