class Atleta:
    def __init__(self, nombre: str, Max_valor: int = 100, Min_valor: int = 0):
        self.nombre = nombre
        self.energia = Max_valor  
        self.destreza = Max_valor  
        self.Max_valor = Max_valor
        self.Min_valor = Min_valor
        self.contEntrenamientos = 0  

    def entrenar(self, intensidad: int = 5):
        self.energia -= intensidad

        if self.energia < self.Min_valor:
            self.energia = self.Min_valor
        else:
            self.contEntrenamientos += 1

        if self.contEntrenamientos == 5:
            self.destreza += 1
            self.contEntrenamientos = 0  
            if self.destreza > self.Max_valor:
                self.destreza = self.Max_valor

    def dormir(self, recuperar: int = 20):
        self.energia += recuperar
        if self.energia > self.Max_valor:
            self.energia = self.Max_valor

    def mismaDestrezaQue(self, otro_atleta):
        return self.destreza == otro_atleta.destreza

    def esMejorQue(self, otro_atleta):
        return self.destreza > otro_atleta.destreza
