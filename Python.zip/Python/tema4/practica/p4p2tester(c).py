
from p4p2 import Empleado

class EmpleadoTester:
    @staticmethod
    def ejecutar_test():

        legajo = int(input("Ingrese el legajo del empleado: "))
        horas_trabajadas = int(input("Ingrese la cantidad de horas trabajadas en el mes: "))
        valor_hora = float(input("Ingrese el valor de la hora trabajada: "))

        empleado = Empleado(legajo)

        empleado.CantidadHorasTrabajadas(horas_trabajadas)
        empleado.ValorDelasHoras(valor_hora)

        print(f"Legajo del empleado: {empleado.LegajoEmpleado()}")
        print(f"Sueldo calculado: ${empleado.ObtenerSueldo():.2f}")

if __name__ == "__main__":
    EmpleadoTester.ejecutar_test()
