from p4p5 import MascotaVirtual

def menu(nombre):
    print(f"""
    ╔════════════════════════════════╗
    ║        TU GATO VIRTUAL         ║
    ╠════════════════════════════════╣
    ║                                ║
    ║      /\_/\                     ║
    ║     ( o.o )  ¡Hola!            ║
    ║      > ^ <  Soy {nombre}       ║
    ║                                ║
    ╠════════════════════════════════╣
    ║ 1. Comer                       ║
    ║ 2. Jugar                       ║
    ║ 3. Baño                        ║
    ║ 4. Ver estado                  ║
    ║ 5. Ver humor                   ║
    ║ 6. Salir                       ║
    ╚════════════════════════════════╝
    """)

def main():
    nombre = input("Ponle un nombre a tu gato: ")
    mascota = MascotaVirtual(nombre)
    vivo = True

    while vivo: 
        menu(nombre)
        try:
            opcion = int(input("Ingrese una opcion: "))
        except ValueError:
            print("Por favor, ingresa un numero valido.")
            continue
        
        if opcion == 1:
            mascota.comer()
            print(f"{nombre} está comiendo.")
        elif opcion == 2: 
            mascota.jugar()
            print(f"{nombre} está jugando.")
        elif opcion == 3:
            mascota.bañar()
            print(f"{nombre} se está bañando.")
        elif opcion == 4:
            print(f"El estado de {nombre} es: {mascota.mostrar_estado()}")
        elif opcion == 5:
            print(f"El humor de {nombre} es: {mascota.humor()}")
        elif opcion == 6:
            print(f"{nombre} se despide.")
            break
        else:
            print("Opcion no valida. Intenta de nuevo.")
        
        # Verificar si la energía ha llegado a 0
        if mascota.energia <= 0:
            print(f"{nombre} ha muerto por falta de energía. :(")
            vivo = False

if __name__ == "__main__":
    main()
