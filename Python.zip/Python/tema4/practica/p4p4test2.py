import random
from p4p4 import Automovil

class Tester:
    def __init__(self, automovil: Automovil):
        self.automovil = automovil

    def ejecutar_tests(self, num_operaciones: int):
        for _ in range(num_operaciones):
            operacion = random.randint(0, 3)
            
            if operacion == 0:  
                incremento = random.uniform(1, 20)
                print(f"Acelerando en {incremento:.2f} km/h.")
                self.automovil.acelerar(incremento)
            
            elif operacion == 1:  
                decremento = random.uniform(1, self.automovil.velocidadActual)
                print(f"Frenando en {decremento:} km/h.")
                self.automovil.frenar(decremento)
            
            elif operacion == 2:  
                print("Frenado completo.")
                self.automovil.frenarCompleto()
            
            elif operacion == 3:  
                distanciaKM = random.uniform(10, 100)
                minutos = self.automovil.calcularMinutosParaLlegar(distanciaKM)
                print(f"Distancia: {distanciaKM:.2f} km. Minutos para llegar: {minutos}")

            
            print(f"Velocidad actual: {self.automovil.obtenerVelocidadActual():} km/h.\n")

def main():
    modelo = input("Ingrese el nombre del modelo del auto: ")
    marca = input("Ingrese la marca del auto: ")
    anio = int(input("Ingrese el año donde se estreno el auto: "))
    velocidadMaxima = float(input("Ingrese la velocidad maxima que puede alcanzar el auto: "))
    velocidadActual = float(input("Ingrese la velocidad actual del auto: "))

    auto = Automovil(marca, modelo, anio, velocidadMaxima, velocidadActual)
    tester = Tester(auto)
    tester.ejecutar_tests(4)  

if __name__ == "__main__":
    main()
