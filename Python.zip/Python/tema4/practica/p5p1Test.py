from p5p1 import Atleta
def menu():
    print(f"""Bienvenido al menú de Atletas:
          1-Entrenar
          2-Dormir
          3-Salir""")

def main():
    nombre = input("Ingrese el nombre del atleta: ")
    atleta = Atleta(nombre) 
    boleano = True
    while boleano:
        menu()  
        
        try:
            opcion = int(input("Ingrese una opcion: "))
        except ValueError:
            print("ingresa algo bien porfavor <3.")
            continue  

        if opcion == 1:
            atleta.entrenar()
            print(f"{nombre} esta entrenando como un personaje de dibujos animados.")
        
        elif opcion == 2:
            atleta.dormir()
            print(f"{nombre} esta durmiendo como un animal de campo.")
        
        elif opcion == 3:
            print(f"{nombre} se despide epicamente mientras va desapareciendo poco a poco... fue buena la aventura mientras duro")
            break
        
        else:
            print("ingresa algo bien porfavor <3.")


if __name__ == "__main__":
    main()
