from abc import ABC, abstractmethod

# Definimos la clase Color (debes implementar esta clase según tus necesidades)
class Color:
    pass

# Definimos la clase padre Prenda
class Prenda(ABC):
    # Definimos los atributos
    def __init__(self, codigo: int, nombre: str, talle: float, color: Color, stock: int, precio: float):
        if not isinstance(codigo, int) or codigo < 0:
            raise TypeError("El código debe ser un entero positivo.")
        if not isinstance(nombre, str) or not nombre.strip():
            raise TypeError("El nombre debe ser una cadena no vacía.")
        if not isinstance(talle, (int, float)) or talle <= 0:
            raise TypeError("El talle debe ser un número positivo.")
        if not isinstance(color, Color):
            raise TypeError("El color debe ser una instancia de la clase Color.")
        if not isinstance(stock, int) or stock < 0:
            raise TypeError("El stock debe ser un entero no negativo.")
        if not isinstance(precio, (int, float)) or precio < 0:
            raise TypeError("El precio debe ser un número no negativo.")

        self.__codigo = codigo
        self.__nombre = nombre
        self.__talle = talle
        self.__color = color
        self.__stock = stock
        self.__precio = precio
        
    @abstractmethod
    def obtenerDescripcion(self):
        pass
    
    def obtenerCosto(self):
        return self.__precio
    
    def stockDisponible(self, cantidad):
        return self.__stock >= cantidad


# Definimos la clase hija Ropa
class Ropa(Prenda):
    # Definimos los atributos
    def __init__(self, codigo: int, nombre: str, talle: float, color: Color, stock: int, precio: float,
                 estacional: bool, planchado: bool, aptoLavarropas: bool):
        super().__init__(codigo, nombre, talle, color, stock, precio)
        if not isinstance(estacional, bool):
            raise TypeError("Estacional debe ser un booleano.")
        if not isinstance(planchado, bool):
            raise TypeError("Planchado debe ser un booleano.")
        if not isinstance(aptoLavarropas, bool):
            raise TypeError("Apto para lavarropas debe ser un booleano.")

        self.__estacional = estacional
        self.__planchado = planchado
        self.__aptoLavarropas = aptoLavarropas

    def obtenerDescripcion(self):
        return f"Ropa: {self.__nombre}, Talle: {self.__talle}, Precio: {self.obtenerCosto()}, Estacional: {self.__estacional}"
    
    def esEstacional(self):
        return self.__estacional
    
    def requierePlanchado(self):
        return self.__planchado
    
    def esAptoLavarropas(self):
        return self.__aptoLavarropas


# Definimos la clase hija Calzado
class Calzado(Prenda):
    # Definimos los atributos
    def __init__(self, codigo: int, nombre: str, talle: float, color: Color, stock: int, precio: float,
                 material: str, suela: str, deportivo: bool):
        super().__init__(codigo, nombre, talle, color, stock, precio)
        if not isinstance(material, str) or not material.strip():
            raise TypeError("El material debe ser una cadena no vacía.")
        if not isinstance(suela, str) or not suela.strip():
            raise TypeError("La suela debe ser una cadena no vacía.")
        if not isinstance(deportivo, bool):
            raise TypeError("Deportivo debe ser un booleano.")

        self.__material = material
        self.__suela = suela
        self.__deportivo = deportivo

    def obtenerDescripcion(self):
        return f"Calzado: {self.__nombre}, Talle: {self.__talle}, Precio: {self.obtenerCosto()}, Material: {self.__material}, Deportivo: {self.__deportivo}"
    
    def esDeportivo(self):
        return self.__deportivo
