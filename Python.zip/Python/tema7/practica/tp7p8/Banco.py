class Cuenta:
    def __init__(self, saldo=0, extracciones_mensuales=0, depositos_mensuales=0, interes_anual=0, comision_mensual=0):
        if not isinstance(saldo, (int, float)) or saldo < 0:
            raise TypeError
        if not isinstance(extracciones_mensuales, int) or extracciones_mensuales < 0:
            raise TypeError
        if not isinstance(depositos_mensuales, int) or depositos_mensuales < 0:
            raise TypeError
        if not isinstance(interes_anual, (int, float)) or interes_anual < 0:
            raise TypeError
        if not isinstance(comision_mensual, (int, float)) or comision_mensual < 0:
            raise TypeError
        self._Cuenta__saldo = saldo
        self._Cuenta__extracciones_mensuales = extracciones_mensuales
        self._Cuenta__depositos_mensuales = depositos_mensuales
        self._Cuenta__interes_anual = interes_anual / 100
        self._Cuenta__comision_mensual = comision_mensual / 100

    def depositar(self, monto):
        if not isinstance(monto, (int, float)) or monto < 0:
            raise TypeError
        self._Cuenta__saldo += monto
        self._Cuenta__depositos_mensuales += 1

    def retirar(self, retirar):
        if not isinstance(retirar, (int, float)) or retirar < 0:
            raise TypeError
        if self._Cuenta__saldo >= retirar:
            self._Cuenta__saldo -= retirar
            self._Cuenta__extracciones_mensuales += 1
        else: 
            print("Saldo insuficiente")

    def generar_extracto_mensual(self):
        interes_ganado = self._Cuenta__saldo * (self._Cuenta__interes_anual / 12)
        self._Cuenta__saldo += interes_ganado - self._Cuenta__comision_mensual

        if self._Cuenta__extracciones_mensuales > 4:
            comision_adicional = (self._Cuenta__extracciones_mensuales - 4) * 1000
            self._Cuenta__saldo -= comision_adicional
            self._Cuenta__comision_mensual += comision_adicional

        self._Cuenta__extracciones_mensuales = 0
        self._Cuenta__depositos_mensuales = 0

        return f"Saldo de la cuenta: {self._Cuenta__saldo}\nInterés ganado: {interes_ganado}\nComisión mensual: {self._Cuenta__comision_mensual}"


class CuentaAhorros(Cuenta):
    def __init__(self, saldo=0, extracciones_mensuales=0, depositos_mensuales=0, interes_anual=0, comision_mensual=0, activar=True):
        super().__init__(saldo, extracciones_mensuales, depositos_mensuales, interes_anual, comision_mensual)
        self._CuentaAhorros__activar = activar

    def activar_cuenta(self):
        self._CuentaAhorros__activar = True

    def depositar(self, cantidad):
        super().depositar(cantidad)
        if self._Cuenta__saldo < 0:
            self._CuentaAhorros__activar = False
        elif self._Cuenta__saldo == 0:
            self._CuentaAhorros__activar = True

    def retirar(self, cantidad):
        super().retirar(cantidad)
        if self._Cuenta__saldo < 0:
            self._CuentaAhorros__activar = False
        elif self._Cuenta__saldo == 0:
            self._CuentaAhorros__activar = True


class CuentaCorriente(Cuenta):
    def __init__(self, saldo=0, extracciones_mensuales=0, depositos_mensuales=0, interes_anual=0, comision_mensual=0, limite_descubierto=0, penalizaciones=0):
        super().__init__(saldo, extracciones_mensuales, depositos_mensuales, interes_anual, comision_mensual)
        self.limite_descubierto = limite_descubierto
        self.penalizaciones = penalizaciones

    def depositar(self, cantidad):
        if self._Cuenta__saldo < 0:
            self.penalizaciones -= cantidad * 0.02
            if self.penalizaciones < 0:
                self.penalizaciones = 0
        super().depositar(cantidad)

    def retirar(self, cantidad):
        if self._Cuenta__saldo < 0:
            self.penalizaciones -= cantidad * 0.02
            if self.penalizaciones < 0:
                self.penalizaciones = 0
        super().retirar(cantidad)

    def generar_extracto_mensual(self):
        extracto = super().generar_extracto_mensual()
        return f"{extracto}\nPenalizaciones: {self.penalizaciones}"


class Tester:
    def test_cuenta(self):
        cuenta = Cuenta(1000, 5, 3, 5, 2)
        cuenta.depositar(500)
        cuenta.retirar(200)
        print(cuenta.generar_extracto_mensual())

    def test_cuenta_ahorros(self):
        cuenta_ahorros = CuentaAhorros(1000, 5, 3, 5, 2, True)
        cuenta_ahorros.depositar(500)
        cuenta_ahorros.retirar(200)
        cuenta_ahorros.activar_cuenta()
        print(cuenta_ahorros.generar_extracto_mensual())

    def test_cuenta_corriente(self):
        cuenta_corriente = CuentaCorriente(1000, 5, 3, 5, 2, 10000, 0)
        cuenta_corriente.depositar(500)
        cuenta_corriente.retirar(200)
        print(cuenta_corriente.generar_extracto_mensual())

# Run the tests
tester = Tester()
tester.test_cuenta()
tester.test_cuenta_ahorros()
tester.test_cuenta_corriente()