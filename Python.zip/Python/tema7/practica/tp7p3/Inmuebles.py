from Propietario import Propietario

class Inmueble: 
    def __init__(self, codigo: int, domicilio: str, propietario: Propietario, metrosCuadrados: int, estado: int):
        self.codigo = codigo
        self.domicilio = domicilio
        self.propietario = propietario
        self.metrosCuadrados = metrosCuadrados
        self.estado = estado

    def costoAlquiler(self, base: int) -> float:
        return base + (self.metrosCuadrados * 100)
    
    def precioVenta(self, m2: float) -> float:
        return self.metrosCuadrados * m2
