class Propietario:
    def __init__(self, nombre:str, dni:str):
        self.nombre = nombre
        self.dni = dni

        def toString():
            return f"Nombre: {self.nombre}, DNI: {self.dni}"