from Inmuebles import Inmueble
from Inmobiliaria import Inmuebleria 
from Quinta import quinta
from Propietario import Propietario

class Tester:
    @staticmethod
    def test_inmuebles():
        # Crear una inmobiliaria
        inmobiliaria = Inmuebleria([])  # Inicializamos con una lista vacía
        
        # Crear un propietario
        propietario = Propietario("Juan Perez", "1234567890")
        
        # Crear algunos inmuebles
        inmueble1 = Inmueble(1, "Calle 123", propietario, 200, 1)  # Ajustado a los 5 parámetros
        inmueble2 = Inmueble(2, "Calle 456", propietario, 150, 1)
        
        # Añadir los inmuebles a la inmobiliaria
        inmobiliaria.insertar(inmueble1)
        inmobiliaria.insertar(inmueble2)
        
        # Mostrar los inmuebles
        print("\n--- Inmuebles ---")
        for inmueble in inmobiliaria.propiedades:
            print(f"ID: {inmueble.codigo}, Dirección: {inmueble.domicilio}, Propietario: {inmueble.propietario.nombre}")

# Ejecutar el test
Tester.test_inmuebles()