from Inmuebles import Inmueble

class Inmuebleria:
    def __init__(self, propiedades: None):
        self.propiedades = propiedades

    def insertar(self, Inmueble: Inmueble):
        if self.propiedades is None:
            self.propiedades = []
            self.propiedades.append(Inmueble)
        else:
            for prop in self.propiedades:
                if prop.codigo == Inmueble.codigo:
                    print(f"Propiedad con codigo {Inmueble.codigo} ya existe.")
                    return
            self.propiedades.append(Inmueble)


    def Eliminar(self, Inmueble: Inmueble):
        if self.propiedades is None:
            print("No hay propiedades")
            return
        self.propiedades = [prop for prop in self.propiedades if prop.codigo != Inmueble.codigo]
            


    def estaInmueble(self, codigo:int) -> bool:
        if self.propiedades is None:
            boleano = False
            return boleano
        for prop in self.propiedades:
            if prop.codigo == codigo:
                boleano = True
                return boleano 

    def estaInmueble(self, Inmueble: Inmueble) -> bool:
          return self.estaInmueble(Inmueble.codigo)

    def esIgual(self,Inmueble:Inmueble) -> bool:
        if self.propiedades is None:
            booleano = False
            return booleano
        for prop in self.propiedades:
            if prop.codigo == Inmueble.codigo:
                booleano = True
                return booleano
            else: 
                booleano = False
                return booleano
            

    def hayInmueble(self) -> bool:
        if self.propiedades is None:
            boleano = False
            return boleano
        for prop in self.propiedades:
            boleano = True
            return boleano
        
    def contarPropiedadesMasMetros(self, Metros:int) -> int:
        if self.propiedades is None:
            numero = 0
            return numero
        numero = sum(1 for prop in self.propiedades if prop.metrosCuadrados > Metros)
        return numero
    


    def mayorPrecio(self) -> Inmueble:
        if self.propiedades is None:
            return None
        mayor = self.propiedades[0]
        for prop in self.propiedades:
            if prop.precio > mayor.precio:
                mayor = prop
        return mayor
    
    def costoMenosQue(self, costo:int)-> Inmueble:
        if self.propiedades is None:
            return None
        menor = self.propiedades[0]
        for prop in self.propiedades:
            if prop.costo < costo:
                menor = prop
        return menor