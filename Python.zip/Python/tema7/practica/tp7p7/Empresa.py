from Empleado import empleado
class Empresa: 
    def __init__(self,empleado:list ):
        self._empleados = empleado

    def agregar_empleado(self):
        nombre=input("ingrese el nombre")
        apellido=input("ingrese el apellido")
        dni=input("ingrese el dni")
        if dni != int:
            print("ingrese numeros enteros")
        else: 
            dni = dni 
        fecha_ingreso = ("ingrese la fecha de ingreso")

    
    def eliminar_empleado(self):
        dni=input("ingrese el dni del empleado a eliminar")
        if dni != int:
            print("ingrese numeros enteros")
        else:
            dni = dni
            for empleado in self.empleados:
                if empleado.dni == dni:
                    self.empleados.remove(empleado)
                    print("Empleado eliminado con exito")
                    return
            print("Empleado no encontrado")

    def consultar_salario(self):
        dni=input("ingrese el dni del empleado")
        if dni != int:
            print("ingrese numeros enteros")
        else:
            dni = dni
            for empleado in self.empleados:
                if empleado.dni == dni:
                    print(f"El salario del empleado con DNI {dni} es: {empleado.calcular_salario()}")
                    return
            print("Empleado no encontrado")

    def empleado_mas_clientes_captados(self):
        max_clientes = 0
        for empleado in self.empleados:
            if empleado.clientes_captados > max_clientes:
                max_clientes = empleado.clientes_captados
                empleado_mas_clientes = empleado
                print(f"El empleado con mayor cantidad de clientes captados es: {empleado_mas_clientes.nombre} {empleado_mas_clientes.apellido}")


    