from Empleado import empleado
class Comision(empleado):
    def __init__(self, nombre:str, apellido:str, dni:int, sueldoBase:float, salario_minimo:float, clientes_captados:int, monto_por_cliente):
        super().__init__(nombre, apellido, dni, sueldoBase)
        self.__salario_minimo = salario_minimo
        self.__clientes_captados = clientes_captados
        self.__monto_por_cliente = monto_por_cliente

    def calcular_salario(self):
        if self.__clientes_captados > 0:
            return self.__sueldoBase + (self.__clientes_captados * self.__monto_por_cliente)
        else:
            return self.__sueldoBase
        