from Empleado import empleado
from datetime import datetime

class SueldoFijo(empleado):
    def __init__(self, nombre:str, apellido:str, dni:int, sueldo_basico:int):
        super().__init__(nombre, apellido, dni)
        self.__sueldo_basico = sueldo_basico

    def calcularSalario(self):

        ano_actual = datetime.now().year
        anos_de_servicio = ano_actual - self.get_fecha_ingreso().year


        if anos_de_servicio <= 2:
            porcentaje_adicional = 0
        elif anos_de_servicio <= 5:
            porcentaje_adicional = 0.05
        else:
            porcentaje_adicional = 0.10


        salario_total = self.__sueldo_basico * (1 + porcentaje_adicional)

        return salario_total
    

