from Fecha import Fecha
class empleado:
    def __init__ (self, dni:str, nombre:str,apellido:str,fecha_ingreso:Fecha):
        self._dni = dni
        self._nombre = nombre
        self._apellido = apellido
        self._fecha_ingreso = fecha_ingreso

    
    def calcular_salario(self):
        pass

    def calcular_anos_servicio(self):
        anosServicio=self._fecha_ingreso + Fecha
        return anosServicio

