from Suscripcion import Suscripcion
class SuscripcionGratuita(Suscripcion):
    def __init__(self, nombre:str, email:str, telefono:str, tiempoSinPublicidad: int, tiempoReproducido:int):
        super().__init__(nombre, email, telefono, tiempoSinPublicidad, tiempoReproducido)
        
    def reproducirMusica(self):
        return super().reproducirMusica()
    
    def interrumpirConPublicidad(self):
     return print("compra neumaticos marca dami")