from Suscripcion import Suscripcion
class SuscripcionPaga(Suscripcion):
    def __int__(self, nombre:str, email:str, telefono:str,MaxDispositivos:int,dispositivos:list):
        super().__init__(nombre, email, telefono, MaxDispositivos, dispositivos)

    def reproducirMusica(self):
        return super().reproducirMusica()

    def descargarMusica(self):
        return super().descargarMusica()
    
    def elegirCancion(self):
        return super().elegirCancion()
    
    def habilitarDispositivo(self):
        return super().habilitarDispositivo()