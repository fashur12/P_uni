from Pais import Pais
class Suscripcion:
    def __int__(self, nombre:str, email:str, telefono:str):
        self.nombre = nombre
        self.email = email
        self.telefono = telefono


    def reproducirMusica(self):
        print(f"Reproduciendo musica en pichiland")