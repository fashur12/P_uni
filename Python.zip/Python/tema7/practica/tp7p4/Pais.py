class Pais:
    def __int__(self, codigo:int, nombre: str, cantidadDispositivos:int):
        self.codigo = codigo
        self.nombre = nombre
        self.cantidadDispositivos = cantidadDispositivos
    