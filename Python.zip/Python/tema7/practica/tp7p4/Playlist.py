from Cancion import Cancion
class Playlist:
    def __int__(self, codigo:int, nombre:str):
        self.codigo = codigo
        self.nombre = nombre
        
    def agregarCancion(self, cancion:Cancion):
        pass

    def eliminarCancion(self, cancion:Cancion):
        pass