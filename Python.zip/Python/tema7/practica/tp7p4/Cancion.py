from  Playlist import Playlist
class Cancion: 
    def __init__ (self,codigo:int, nombre:str, duracion : int, genero:str):
        self.codigo = codigo
        self.nombre = nombre
        self.duracion = duracion
        self.genero = genero

    def reproducir(self):
        print(f"Reproduciendo los piojos en fm pepe medina {self.nombre}")