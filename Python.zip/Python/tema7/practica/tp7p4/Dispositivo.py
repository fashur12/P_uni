from SuscripcionGratuita import SuscripcionGratuita
from SuscripcionPaga import SuscripcionPaga
class Dispositivo:
    def __init__(self, id:int, nombre:str,tipo:str):
        self.id = id
        self.nombre = nombre
        self.tipo = tipo
    
