from PolizaMuebles import PolizaInmueble

class Aseguradora:
    def __init__(self):
        self.seguros = []

    def insertar(self, poliza):
        self.seguros.append(poliza)
        # Ordenar lista de seguros por número de poliza
        self.seguros.sort(key=lambda p: p.numero)

    def eliminar(self, poliza):

        self.seguros = [p for p in self.seguros if p.numero != poliza.numero]

    def existePoliza(self, poliza):
   
        return any(p.numero == poliza.numero for p in self.seguros)

    def hayPolizas(self):
        return len(self.seguros) > 0

    def costoTotal(self):
        return sum(p.costoPoliza() for p in self.seguros)

    def esIgual(self, aseguradora):
        # Compara si las dos aseguradoras tienen los mismos seguros
        return self.seguros == aseguradora.seguros
