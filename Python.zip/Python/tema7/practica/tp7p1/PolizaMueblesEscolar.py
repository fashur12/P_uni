from PolizaMuebles import PolizaInmueble

class PolizaInmuebleEscolar(PolizaInmueble):
    def __init__(self, numero, incendio, explosion, robo, cantPersonas, montoEquipamiento, montoMobiliario, montoPersona):
        super().__init__(numero, incendio, explosion, robo)
        self.cantPersonas = cantPersonas
        self.montoEquipamiento = montoEquipamiento
        self.montoMobiliario = montoMobiliario
        self.montoPersona = montoPersona

    def costoPoliza(self):
        # Cálculo de costo para PolizaInmuebleEscolar
        return super().costoPoliza() + self.montoEquipamiento + self.montoMobiliario + (self.cantPersonas * self.montoPersona)

    def toString(self):
        return f"Poliza Escolar {self.numero} - Costo: {self.costoPoliza()}"
