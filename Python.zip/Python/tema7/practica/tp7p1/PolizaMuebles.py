class PolizaInmueble:
    def __init__(self, numero, incendio, explosion, robo):
        self.numero = numero
        self.incendio = incendio
        self.explosion = explosion
        self.robo = robo

    def costoPoliza(self):

        return self.incendio + self.explosion + self.robo

    def toString(self):
        return f"Poliza {self.numero} - Costo: {self.costoPoliza()}"
