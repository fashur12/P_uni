from Aseguradora import Aseguradora
from PolizaMuebles import PolizaInmueble
from PolizaMueblesEscolar import PolizaInmuebleEscolar

class Tester:
    @staticmethod
    def test():
        # Crear una aseguradora
        aseguradora = Aseguradora()

        # Crear algunas pólizas
        poliza1 = PolizaInmueble(1, 100.0, 50.0, 75.0)
        poliza2 = PolizaInmuebleEscolar(2, 200.0, 80.0, 100.0, 50, 300.0, 150.0, 20.0)
        poliza3 = PolizaInmueble(3, 120.0, 70.0, 90.0)

        # Insertar pólizas
        aseguradora.insertar(poliza1)
        aseguradora.insertar(poliza2)
        aseguradora.insertar(poliza3)

        # Mostrar las pólizas insertadas
        print("Pólizas después de la inserción:")
        for poliza in aseguradora.seguros:
            print(poliza.toString())

        # Verificar la existencia de una póliza
        print("\n¿Existe la póliza 2?", aseguradora.existePoliza(poliza2))

        # Eliminar una póliza
        aseguradora.eliminar(poliza1)

        # Mostrar las pólizas después de eliminar
        print("\nPólizas después de eliminar la póliza 1:")
        for poliza in aseguradora.seguros:
            print(poliza.toString())

        # Mostrar el costo total de las pólizas
        print("\nCosto total de las pólizas:", aseguradora.costoTotal())

        # Comparar aseguradoras
        aseguradora2 = Aseguradora()
        aseguradora2.insertar(poliza2)
        aseguradora2.insertar(poliza3)
        print("\n¿Las aseguradoras son iguales?", aseguradora.esIgual(aseguradora2))

if __name__ == "__main__":
    Tester.test()
