from Vehiculo import Vehiculo

class Moto(Vehiculo):
    def __init__(self, Marca:str, modelo:str, patente:str, color:str, año_fabricacion:int, precio:float, kilometraje:float, tipo_conbustible:str, anchu_manubrio:float, cilindrada:int):
        super().__init__(Marca, modelo, patente, color, año_fabricacion, precio, kilometraje, tipo_conbustible, cilindrada)
        self.__anchura_manubrio = anchu_manubrio

    def consultaMoto(self):
        print(f"Anchura de manubrio: {self.__anchura_manubrio}")
        print(f"Cilindrada: {self.__cilindrada}")
        print(f"Potencia: {self.__potencia}")
        print(f"Velocidad maxima: {self.__velocidad_maxima}")
        print(f"Consumo: {self.__consumo}")

    def modificarCilindrada(self, cli:int):
        self.__cilindrada = cli
        print(f"Cilindrada modificada a: {self.__cilindrada}")