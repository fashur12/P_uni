from Vehiculo import Vehiculo

class Auto(Vehiculo):
    def __init__(self, Marca:str, modelo:str, patente:str, color:str, año_fabricacion:int, precio:float, kilometraje:float, tipo_conbustible:str, Cantidad_puertas:int, cilindrada:int, Aire_Acondicionado:bool):
        super().__init__(Marca, modelo, patente, color, año_fabricacion, precio, kilometraje)
        self.__tipo_conbustible = tipo_conbustible
        self.__Cantidad_puertas = Cantidad_puertas
        self.__cilindrada = cilindrada
        self.__Aire_Acondicionado = Aire_Acondicionado

    def consularAuto(self):
        return f"Marca: {self.__marca}, Modelo: {self.__modelo}, Patente: {self.__patente}, Color: {self.__color}, Año de Fabricación: {self.__año_fabricacion}, Precio: {self.__precio}, Kilometraje: {self.__kilometraje}, Tipo de Conbustible: {self.__tipo_conbustible}, Cantidad de Puertas: {self.__Cantidad_}"



def modificarPuertas(self, puertas:int):
    if puertas > 0 and puertas <= 4:
        self.__Cantidad_puertas = puertas
        print("La cantidad de puertas ha sido modificada correctamente.")
    else:
        print("La cantidad de puertas debe ser un numero entero entre 1 y 4.")

