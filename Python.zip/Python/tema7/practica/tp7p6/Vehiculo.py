class Vehiculo: 
    def __init__(self, Marca:str, modelo:str, patente:str, color:str, año_fabricacion:int, precio:float, kilometraje:float, tipo_conbustible:str):
        self.__marca = Marca
        self.__modelo = modelo
        self.__patente = patente
        self.__color = color
        self.__año_fabricacion = año_fabricacion
        self.__precio = precio
        self.__kilometraje = kilometraje
        self.__tipo_conbustible = tipo_conbustible

    def consultarValor(self) ->str:
        return f"El valor del vehiculo maldonado  es ${self.__precio}"
    
    def modificarPrecio(self, precio:float)->float:
     self.__precio = input("ingrese el nuevo precio ")
     if self.__precio>0:
        print("el precio fue modificado")
        return self.__precio
     else: 
        print("el precio debe ser positivo/ingrese numeros")
    
    def modificarKilometraje(self, km:float)->float:
        self.__kilometraje = input("ingrese el nuevo kilometraje ")
        if self.__kilometraje>0:
            print("el kilometraje fue modificado")
            return self.__kilometraje
        else:
            print("el kilometraje debe ser positivo/ingrese numeros")


def eliminarVehiculo(self):
    try:
        confirmation = input("Esta seguro de eliminar el vehiculo? (S/N): ")
        if confirmation.upper() == "S":
            print("El vehiculo fue eliminado")
        else:
            print("Eliminacion cancelada")
    except Exception as e:
        print(f"Error: {str(e)}")