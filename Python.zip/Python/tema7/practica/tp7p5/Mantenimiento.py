from Empleados import Empleado
class Mantenimiento (Empleado):
    def __init__(self, nombre:str, apellido:str, Dni: int, legajo:int, area:str):
        super().__init__(nombre, apellido, Dni, legajo)
        self.__area = area

    
    def getLegajo(self):
        return self._legajo
    
    def getArea(self):
        return self.__area