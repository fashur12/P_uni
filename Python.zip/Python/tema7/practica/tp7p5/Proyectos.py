from Programador import Programador
class Programador: 
    def __init__(self, legajo:int, Nombre:str):
        self.legajo = legajo
        self.Nombre = Nombre

        def getNombreProyecto(self)->str:
            return f"El programador {self.Nombre} está trabajando en el proyecto {self.getNombreProyecto()}"
