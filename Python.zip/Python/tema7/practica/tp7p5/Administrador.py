from Empleados import Empleado
class Administrador(Empleado):
    def __init__(self, nombre:str, apellido:str, Dni: int, Posicion:str):
        super().__init__(nombre, apellido, Dni)
        self.Posicion = Posicion

 
    def getLegajo(self):
        return self.legajo
    
    def getArea(self):
        return self.Area
    
