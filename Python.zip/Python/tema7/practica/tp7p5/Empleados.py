class Empleado:
    def __init__(self, nombre:str, apellido:str, Dni: int):
        self.nombre = nombre
        self.apellido = apellido
        self.Dni = Dni
    