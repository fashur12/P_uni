from Empleados import Empleado
class Programador(Empleado):
    def __init__(self, nombre:str, apellido:str, Dni: int, proyecto:str, legajo:int):
        super().__init__(nombre, apellido, Dni, legajo)
        self.proyecto = proyecto
  
def getLegajo(self):
        return self.legajo

def getPosicion(self):
     return self.proyecto
