from InMueble import inmueble
class quinta(inmueble):
    def __init__(self, codigo:int, domicilio:str, propietario:str, metrosCuadrados:int, estado:int, metrosParque:int):
        super().__init__(codigo, domicilio, propietario, metrosCuadrados, estado)
        self.metrosParque = metrosParque

    def CostoAlquiler(self, base):
        return super().CostoAlquiler(base)
    
    def precioVenta(self, m2):
        return super().precioVenta(m2)

