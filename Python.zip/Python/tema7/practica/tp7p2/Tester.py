from InMueble import inmueble
from Quinta import quinta
from Departamento import departamento

class tester:
    @staticmethod
    def test_inmueble():
        print("\n--- Test Inmueble ---")
        inmueble_obj = inmueble(1, "Casa", "Calle 123", 2000, 4)
        print(inmueble_obj)
        
        print("\n--- Test Quinta ---")
        quinta_obj = quinta(2, "Apartamento", "Calle 456", 3000, 4, "2do Piso", True, 100)
        print(quinta_obj)
        
        print("\n--- Test Departamento ---")
        departamento_obj = departamento(3, "Departamento", "Calle 789", 4000, 3, "3er Piso", False, 50)
        print(departamento_obj)

if __name__ == "__main__":
    tester.test_inmueble()