class inmueble:
    def __init__(self, codigo:int, domicilio:str, propietario:str, metrosCuadrados:int, estado:int):
        self.codigo = codigo
        self.domicilio = domicilio
        self.propietario = propietario
        self.metrosCuadrados = metrosCuadrados
        self.estado = estado

    def CostoAlquiler(self,base:int):
        return self.metrosCuadrados * base
    
    def precioVenta(self, m2:float):
        return self.metrosCuadrados * m2
    
    def __str__(self):
        return f"Inmueble: {self.codigo}, Domicilio: {self.domicilio}, Propietario: {self.propietario}, Metros Cuadrados: {self.metrosCuadrados}, Estado: {self.estado}"
