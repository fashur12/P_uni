from abc import ABC, abstractmethod
from datetime import datetime


class Empleado(ABC):
    def __init__(self,DNI:str,nombre:str, apellido:str, anio_ingreso:str ):
        if not isinstance (DNI, str) or DNI == " " or  DNI.isspace():
            raise ValueError("DNI invalido")
        if not isinstance (nombre, str) or nombre == " " or  nombre.isspace():
            raise ValueError("Nombre invalido")
        if not isinstance (apellido, str) or apellido == " " or  apellido.isspace():
            raise ValueError("Apellido invalido")
        if not isinstance (anio_ingreso, str) or anio_ingreso == " " or anio_ingreso():
            raise ValueError("Año de ingreso invalido")
        self.__DNI = DNI
        self.__nombre = nombre
        self.__apellido = apellido
        self.__apellido = apellido 
        self.__anio_ingreso = anio_ingreso

        @abstractmethod
        def obtenerSaliro(self)->float:
            pass 

        def nombreCompleto(self)->str:
            return f"{self.__apellido}, {self.__nombre}"
        
        def antiguedadEnAnios(self)->int:
            return datetime.now().year - int(self.__anio_ingreso)
        def tostring(self)->str:
            return f"Empleado: {self.nombreCompleto()}, DNI: {self.__DNI}, Antiguedad: {self.antiguedadEnAnios()} años"
        


        class EmpleadoAComision(Empleado):
            def __init__(self, DNI:str, nombre:str, apellido:str, anio_ingreso:str, salarioMinimo:float, cantClientesCaptados:int, montoPorCliente:float):
                super().__init__(DNI, nombre, apellido, anio_ingreso)
                self.__salarioMinimo = salarioMinimo
                self.__cantClientesCaptados = cantClientesCaptados
                self.__montoPorCliente = montoPorCliente
                if not isinstance (salarioMinimo, float,int) or salarioMinimo == " " or salarioMinimo < 0:
                    raise ValueError("Salario mínimo invalido")
                if not isinstance (cantClientesCaptados, int) or cantClientesCaptados < 0:
                    raise ValueError("Cant. de clientes captados invalida")
                if not isinstance (montoPorCliente, float, int ) or montoPorCliente <0:
                    raise ValueError("Monto por cliente invalido")
                

            def obtenerSalario(self) -> float:
                salario = self.__cantClientesCaptados * self.__montoPorCliente
                if salario < self.__salarioMinimo:
                    salario = self.__salarioMinimo
                    return salario
                
            def obtenerCantClientesCaptados(self) -> int:
                return self.__cantClientesCaptados
            
            def toString(self) ->str:
                return super().tostring() + f", Salario: {self.obtenerSalario()}, Cant. clientes captados: {self.__cantClientesCaptados}, Monto por cliente: {self.__montoPorCliente}"




class EmpleadoSalarioFijo(Empleado):
        __PORC_2_a_5 = 0.05
        __PORC_MAS_DE_5 = 0.1
        __ANiO_LIMITE_INFERIOR = 2
        __ANiO_LIMITE_SUPERIOR = 5

        def __init__(self, dni:str, nombre:str, apellido:str, anioIngreso:int, sueldoBasico: float):
            super().__init__(dni, nombre, apellido, anioIngreso)
            if not isinstance(sueldoBasico, (int, float)) or sueldoBasico <= 0:
                raise ValueError
            self.__sueldoBasico = sueldoBasico

        def obtenerSalario(self)-> float:
            return self.__sueldoBasico + self.__sueldoBasico * self.obtenerPorcentajeAdicional()

        def obtenerPorcentajeAdicional(self)-> float:
            if self.obtenerAntiguedadEnAnios() <= self.__ANIO_LIMITE_INFERIOR:
                return self.__PORC_2_a_5
            elif self.obtenerAntiguedadEnAnios() <= self.__ANIO_LIMITE_SUPERIOR:
                return self.__PORC_MAS_DE_5
            else:
                return 0.0
            
        def toString(self):
            return super().tostring() + f", Sueldo: {self.obtenerSalario()}"
        

class Empresa:
    def __init__(self,lista = None):
        self.__listaEmpleados = []

    def agregarEmpleado(self, empleado: Empleado):
        self.__listaEmpleados.append(empleado)
        
    def empleadoConMasCliente(self)->Empleado:
        pass

    def esIgual(empresa:str) -> bool:
        pass

