from abc import ABC, abstractmethod  # Importa clases abstractas y decorador para metodos abstractos

# definicion de la clase abstracta Persona
class Persona(ABC):
    # Constructor que inicializa nombre y edad
    def __init__(self, nombre: str, edad: int):
        # validiacion para asegurarse de que nombre sea una cadena no vacía ni con solo espacios
        if not isinstance(nombre, str) or nombre == " " or nombre.isspace():
            raise TypeError
        # validiacion para que edad sea un entero entre 0 y 150
        if not isinstance(edad, int) or edad < 0 or edad > 150:
            raise TypeError
        
        self._nombre = nombre  # Atributo protegido para el nombre
        self._edad = edad      # Atributo protegido para la edad

    # metodo abstractos que deben ser implementados por las subclases
    @abstractmethod
    def beber(self) -> str:
        pass

    @abstractmethod
    def hablar(self) -> str:
        pass

    @abstractmethod
    def saludar(self) -> str:
        pass

# Clase Bebida
class Bebida:
    
# atriburos de la clase Bebida con verificacion de tipos y valores validos:    

    def _init_(self, nombre:str, precio:float, tipo:str, stock:int):
        if not isinstance(nombre, str) or nombre == " " or nombre.isspace():
            raise TypeError
        if not isinstance(precio, (int, float)) or precio <= 0:
            raise TypeError
        if not isinstance(tipo, str) or tipo == " " or tipo.isspace():
            raise TypeError
        if not isinstance(stock, int) or stock < 0:
            raise TypeError
        self.__nombre = nombre
        self.__precio = precio
        self.__tipo = tipo
        self.__stock = stock

    
    def consultarStock(self) -> int:
        return self.__stock
    
    def reducirStock(self, cantidad:int):
        if not isinstance(cantidad, int) or cantidad <= 0:
            raise TypeError("El valor no puede ser menor o igual a cero")
        if cantidad <= self.__stock:
            self.__stock -= cantidad
        else:
            print("No hay suficiente stock")
            
    def aumentarStock(self, cantidad:int):
        if not isinstance(cantidad, int) or cantidad <= 0:
            raise TypeError("El valor no puede ser menor o igual a cero")
        self.__stock += cantidad

# Clase Cliente que hereda de Persona
class Cliente(Persona):
    def __init__(self, nombre: str, edad: int, dinero: float, bebidaFavorita: Bebida):
        super().__init__(nombre, edad)  # Llama al constructor de Persona
        # validiacion para que dinero sea un numero positivo
        if not isinstance(dinero, (int, float)) or dinero < 0:
            raise TypeError
        # validacion de bebidaFavorita: debe ser una instancia de Bebida
        if not isinstance(bebidaFavorita, Bebida):
            raise TypeError
        
        self.__dinero = dinero  # Atributo privado para el dinero
        self.__bebidaFavorita = bebidaFavorita  # Atributo privado para la bebida favorita

    # metodo para clonar el objeto Cliente en profundidad
    def clonarProfundidad(self):
        # Clona la bebida favorita
        bebida_clonada = self.__bebidaFavorita.clonar()  
        # Retorna un nuevo Cliente con los mismos atributos, incluyendo la bebida clonada
        return Cliente(self._nombre, self._edad, self.__dinero, bebida_clonada)
    def beber(self) -> str:
    # implementacion del metodo beber para Cliente  # Implementación del método beber para Cliente def beber(self) -> str:
        print(f"Que rica mi {self.__bebidaFavorita}")
        
    def hablar(self) -> str:
        print(f"Cantinero, deme otra{self.__bebidaFavorita}")
        
    def saludar(self) -> str:
        print("Buenas tardes Moe")

# Clase Empleado que hereda de Persona
class Empleado(Persona):
    def __init__(self, fechaIngreso: str, nombre: str, edad: int):
        super().__init__(nombre, edad)  # Llama al constructor de Persona
        if not isinstance(fechaIngreso, str) or fechaIngreso == " " or fechaIngreso.isspace():
            raise ValueError("Fecha de ingreso debe ser una cadena válida")
        
        self.__fechaIngreso = fechaIngreso  # Atributo privado para la fecha de ingreso

    # implementacion del metodo beber para Empleado
    def beber(self) -> str:
        return "Tomando agua en horario de trabajo..."

    # Implementacion del metodo hablar para Empleado
    def hablar(self) -> str:
        return "¿Qué le puedo ofrecer para tomar?"

    # Implementacion del metodo saludar para Empleado
    def saludar(self) -> str:
        return "Bienvenido a la taberna de Moe!"
