list_original = []
for i in range(3):
 num= input("ingrese 3 numeros en la lista:")
 list_original.append(int(num))

list_nueva=[num **2 for num in list_original]
print(f"lista original:{list_original}")
print(f"lista nueva:{list_nueva}")

