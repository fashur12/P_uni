def vocales(palabra):
    vocales = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']
    contador = 0
    for letra in palabra:
        if letra in vocales:
            contador += 1
    return contador

def salir(palabra):
    return palabra.lower() == "salir"

boleano = True
while boleano:
    palabra = input("Enter a word: ")
    if salir(palabra):
        boleano = False
    else:
        contador = vocales(palabra)
        print(f"la palabra es: '{palabra}' y la cantid de  vocales son: {contador} .")