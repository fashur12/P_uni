estudiantes = [
    {"nombre y apellido": "Pepe", "legajo": 12345, "nota del parcial1": 90, "nota del parcial2": 90, "nota del final": 90},
    {"nombre y apellido": "Maria", "legajo": 67890, "nota del parcial1": 85, "nota del parcial2": 80, "nota del final": 82},
    {"nombre y apellido": "Pedro", "legajo": 13579, "nota del parcial1": 75, "nota del parcial2": 70, "nota del final": 73},
    {"nombre y apellido": "Ana", "legajo": 24680, "nota del parcial1": 60, "nota del parcial2": 60, "nota del final": 50}
]


nombres = [estudiante["nombre y apellido"] for estudiante in estudiantes]
print("Nombres:", nombres)


estudiantes_aprobados = [
    estudiante["nombre y apellido"]
    for estudiante in estudiantes
    if estudiante["nota del parcial1"] > 70 and estudiante["nota del parcial2"] > 70 and estudiante["nota del final"] > 70
]
print("Los estudiantes con calificacion superior a 70/ que aprobaron son:", estudiantes_aprobados)


estudiantes_desaprobados = [
    estudiante["nombre y apellido"]
    for estudiante in estudiantes
    if estudiante["nota del parcial1"] < 60 or estudiante["nota del parcial2"] < 60 or estudiante["nota del final"] < 60
]
print("Los estudiantes con calificacion inferior a 60/ que desaprobaron son:", estudiantes_desaprobados)