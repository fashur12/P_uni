diccionario = {
    "árbol": "Planta de tronco leñoso.",
    "avión": "Medio de transporte aéreo.",
    "bicicleta": "Medio de transporte de dos ruedas.",
    "auto": "Vehiculo motorizado de cuatro ruedas.",
    "barco": "Medio de transporte acuático."
}

letra = 'a'  
palabras_con_letra = [palabra for palabra in diccionario.keys() if palabra.lower().startswith(letra)]

print(palabras_con_letra)  
