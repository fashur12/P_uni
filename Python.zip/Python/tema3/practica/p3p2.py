def nombres(nombres, longitud):
    return[nombre for nombre in nombres if len(nombre)>=longitud]

list_nombres=["eros","laucha","peron","juan"]
filtrado=nombres(list_nombres, 6)
print(f"nombres: {filtrado}")