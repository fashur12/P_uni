lista_original=[1,2,3,4,5,6]

lista_pares=[elementos for elementos in lista_original if elementos % 2 == 0]
lista_impares=[elementos for elementos in lista_original if elementos % 2 !=0]
print(lista_pares)
print(lista_impares)