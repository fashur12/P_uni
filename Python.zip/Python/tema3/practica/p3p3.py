with open("C:/Users/estudiante/Desktop/Python/tema3/practica/data.txt","r") as file:
    leer=[lineas.strip() for lineas in file]
print(leer)