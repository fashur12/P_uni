lista_original = [1, 1, 2, 3, 4, 5]

nueva_lista = [elemento for elemento in lista_original if lista_original.count(elemento) == 1]

print(nueva_lista)