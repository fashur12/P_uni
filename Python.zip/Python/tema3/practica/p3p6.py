personas ={
"lucas": 30,
"juan":90,
"ruso":13,
"pepe":2
}
edad_minima=int(input("ingrese la edad minima:"))
nombres_mayores= [ nombre for nombre, edad, in personas.items() if edad>edad_minima]
print(nombres_mayores)